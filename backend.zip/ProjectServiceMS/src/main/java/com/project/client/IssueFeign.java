package com.project.client;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.project.model.IssueDTO;

@FeignClient(name = "IssueServiceMS", path = "/api/issues")
//@FeignClient(name = "IssueServiceMS", url = "http://localhost:8011/api/issues")
public interface IssueFeign {
	
	@GetMapping("/project/{projectId}")
	public List<IssueDTO> getIssuesByProjectId(@PathVariable Integer projectId) throws Exception;
}
