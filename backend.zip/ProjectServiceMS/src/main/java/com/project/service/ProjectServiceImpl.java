package com.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.client.IssueFeign;
import com.project.entity.Project;
import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private IssueFeign issueFeign;

	@Override
	public List<IssueDTO> getIssuesByProjectId(Integer projectId) throws Exception {
		try {
			List<IssueDTO> issues = issueFeign.getIssuesByProjectId(projectId);
			return issues != null ? issues : new ArrayList<>();
		} catch (Exception exception) {
			throw new Exception("Issue microservice call failed: " + exception.getMessage());
		}
	}

	@Override
	public List<IssueDTO> getIssuesByProjectName(String projectName) throws Exception {
		Project project = projectRepository.findByProjectName(projectName)
				.orElseThrow(() -> new ProjectException("Project not found with name: " + projectName));

		try {
			List<IssueDTO> issues = issueFeign.getIssuesByProjectId(project.getId());
			return issues != null ? issues : new ArrayList<>();
		} catch (Exception exception) {
			throw new Exception("Issue microservice call failed: " + exception.getMessage());
		}
	}

	@Override
	public ProjectDTO getProjectById(Integer projectId) throws ProjectException {
		Optional<Project> optional = projectRepository.findById(projectId);
		ProjectDTO projectDTO = new ProjectDTO();
		try {
			Project project = optional
					.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));

			projectDTO.setId(project.getId());
			projectDTO.setProjectName(project.getProjectName());
			projectDTO.setProjectOwner(project.getProjectOwner());
			projectDTO.setStartDate(project.getStartDate());
			projectDTO.setEndDate(project.getEndDate());
		} catch (ProjectException e) {
			e.printStackTrace();
			throw e;
		}
		return projectDTO;
	}

	@Override
	public String createProject(ProjectDTO projectDTO) throws ProjectException {
		Optional<Project> existing = projectRepository.findByProjectName(projectDTO.getProjectName().trim());
		if (existing.isPresent()) {
			throw new ProjectException("Project name already exists: " + projectDTO.getProjectName());
		}
		Project project = new Project();
		project.setProjectName(projectDTO.getProjectName());
		project.setProjectOwner(projectDTO.getProjectOwner());
		project.setStartDate(projectDTO.getStartDate());
		project.setEndDate(projectDTO.getEndDate());
		try {
			projectRepository.save(project);
		} catch (Exception exception) {
			throw exception;
		}
		return "Project created successfully with Project ID: " + project.getId();
	}

	@Override
	public List<ProjectDTO> getAllProjects() throws ProjectException {
		List<Project> projectsList = projectRepository.findAll();
		List<ProjectDTO> projectDtoList = new ArrayList<>();
		try {
			if (projectsList.isEmpty()) {
				throw new ProjectException("No projects found in the database.");
			}
			for (Project project : projectsList) {
				ProjectDTO dto = new ProjectDTO();
				dto.setId(project.getId());
				dto.setProjectName(project.getProjectName());
				dto.setProjectOwner(project.getProjectOwner());
				dto.setStartDate(project.getStartDate());
				dto.setEndDate(project.getEndDate());
				projectDtoList.add(dto);
			}
		} catch (ProjectException e) {
			e.printStackTrace();
			throw e;
		}
		return projectDtoList;
	}

	@Override
	public List<ProjectDTO> getProjectsByOwner(Integer ownerId) throws ProjectException {
		List<Project> projectsList = projectRepository.findByProjectOwner(ownerId);
		List<ProjectDTO> projectDtoList = new ArrayList<>();
		try {
			if (projectsList.isEmpty()) {
				throw new ProjectException("No projects found for Owner ID: " + ownerId);
			}
			for (Project project : projectsList) {
				ProjectDTO dto = new ProjectDTO();
				dto.setId(project.getId());
				dto.setProjectName(project.getProjectName());
				dto.setProjectOwner(project.getProjectOwner());
				dto.setStartDate(project.getStartDate());
				dto.setEndDate(project.getEndDate());
				projectDtoList.add(dto);
			}
		} catch (ProjectException e) {
			e.printStackTrace();
			throw e;
		}
		return projectDtoList;
	}

	@Override
	public String updateProject(Integer projectId, ProjectDTO projectDTO) throws ProjectException {
		Optional<Project> optional = projectRepository.findById(projectId);
		Project project = optional.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));

		if (projectDTO.getEndDate() != null && projectDTO.getStartDate() != null) {
			if (projectDTO.getEndDate().isBefore(projectDTO.getStartDate())) {
				throw new ProjectException("End date cannot be earlier than start date");
			}
		}

		project.setProjectName(projectDTO.getProjectName());
		project.setProjectOwner(projectDTO.getProjectOwner());
		project.setStartDate(projectDTO.getStartDate());
		project.setEndDate(projectDTO.getEndDate());

		projectRepository.save(project);
		return "Project details updated successfully for Project ID: " + projectId;
	}

	@Override
	public String deleteProject(Integer projectId) throws ProjectException {
		Optional<Project> optional = projectRepository.findById(projectId);
		Project project = optional.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));

		projectRepository.delete(project);
		return "Project deleted successfully with Project ID: " + projectId;
	}

	@Override
	public Map<String, Object> getProjectInsights(Integer projectId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
