package com.project.utility;

public enum Type {
	BUG, TASK, STORY
}
