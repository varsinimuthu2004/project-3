package com.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.client.IssueFeign;
import com.user.entity.User;
import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.UserDTO;
import com.user.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private IssueFeign issueFeign;

	@Override
	public String registerUser(UserDTO userDTO) throws UserException {
		User existingUser = userRepository.findByEmailId(userDTO.getEmailId());
		if (existingUser != null) {
			throw new UserException("User already exists with email ID: " + userDTO.getEmailId());
		}

		User user = new User();
		user.setName(userDTO.getName());
		user.setEmailId(userDTO.getEmailId());
		user.setRole(userDTO.getRole());
		user.setPassword(userDTO.getPassword());
		user.setProfileImage(userDTO.getProfileImage());

		userRepository.save(user);

		return "User registered successfully with User ID: " + user.getUserId();
	}

	@Override
	public UserDTO loginUser(String name, String emailId, String password, String role) throws UserException {
		User user = userRepository.findByEmailId(emailId);
		if (user == null) {
			throw new UserException("User not found with email: " + emailId);
		}
		if (!user.getPassword().equals(password)) {
			throw new UserException("Invalid password");
		}
		if (role != null && !role.trim().isEmpty()) {
			String normalizedInputRole = role.trim().toUpperCase().replace(" ", "_");
			if (user.getRole() != null && !user.getRole().name().equals(normalizedInputRole)) {
				throw new UserException("User role does not match selected role: " + role);
			}
		}
		return mapper.map(user, UserDTO.class);
	}

	@Override
	public UserDTO getUserById(Integer userId) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		UserDTO userDTO = new UserDTO();
		userDTO.setUserId(user.getUserId());
		userDTO.setName(user.getName());
		userDTO.setEmailId(user.getEmailId());
		userDTO.setRole(user.getRole());
		userDTO.setPassword(user.getPassword());
		userDTO.setProfileImage(user.getProfileImage());
		return userDTO;
	}

	@Override
	public List<UserDTO> getAllUsers() throws UserException {
		List<User> usersList = userRepository.findAll();
		if (usersList.isEmpty()) {
			throw new UserException("No users found in the database.");
		}
		List<UserDTO> userdtoList = new ArrayList<>();
		for (User user : usersList) {
			UserDTO dto = new UserDTO();
			dto.setUserId(user.getUserId());
			dto.setName(user.getName());
			dto.setEmailId(user.getEmailId());
			dto.setRole(user.getRole());
			dto.setPassword(user.getPassword());
			dto.setProfileImage(user.getProfileImage());
			userdtoList.add(dto);
		}
		return userdtoList;
	}

	@Override
	public String updateUser(Integer userId, UserDTO userDTO) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		user.setEmailId(userDTO.getEmailId());
		user.setName(userDTO.getName());
		user.setRole(userDTO.getRole());
		user.setPassword(userDTO.getPassword());
		user.setProfileImage(userDTO.getProfileImage());

		userRepository.save(user);
		return "User details updated successfully for User ID: " + userId;
	}

	@Override
	public String deleteUser(Integer userId) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		userRepository.delete(user);
		return "User deleted successfully with User ID: " + userId;
	}

	@Override
	public List<IssueDTO> getIssuesByUserId(Integer userId) throws Exception {
	    List<IssueDTO> issues = null;
	    try {
	        // 1. Actually call the external microservice using the Feign client
	        issues = issueFeign.getIssuesByAssigneeId(userId);
	        
	        // 2. Validate the response payload safely
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("Issue service returned no issues found for the user.");
	        }
	    } catch (Exception exception) {
	        // 3. Fallback tracking if the issue microservice is completely down or times out
	        throw new Exception("Issue service is down or an error occurred: " + exception.getMessage());
	    }
	    
	    return issues;
	}
	@Override
	public List<IssueDTO> getIssuesByUsername(String username) throws Exception {
 
	    User user = userRepository.findByName(username)
	            .orElseThrow(() -> new UserException("User profile not found with name: " + username));
	            
	    List<IssueDTO> issues = null;
	    try {
	        issues = issueFeign.getIssuesByAssigneeId(user.getUserId());
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("No active issues found assigned to user name: " + username);
	        }
	    } catch (Exception exception) {
	        throw new Exception("Downstream issue service communication failure: " + exception.getMessage());
	    }
	    return issues;
	}

}