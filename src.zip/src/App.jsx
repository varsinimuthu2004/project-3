import './App.css'
import { Link, useNavigate } from 'react-router-dom'
import { useContext } from 'react'
import { AuthContext } from './context/AuthContext'
import ViewAllProducts from './components/ViewAllProducts'
import ViewAllInventory from './components/ViewAllInventory'
import AddProductForm from './components/AddProductForm'
import NewInventory from './components/NewInventory'
import UserSignupForm from './components/UserSignupForm'
import UserLoginForm from './components/UserLoginForm'
import UpdateProductForm from './components/UpdateProductForm'
import PlaceOrderForm from './components/PlaceOrderForm'
import GetAllOrders from './components/GetAllOrders'
import { Routes, Route } from 'react-router-dom'

function Navbar() {
  
  const {isLoggedIn, user, ctxLogout} = useContext(AuthContext);

  const navigate = useNavigate();

  const handleLogout = () => {
    ctxLogout();
    navigate('/login');
  }

  return (
    <nav aria-label='Main navigation'>
      <div className='navbar navbar-expand-lg navbar-dark bg-dark py-3 shadow-sm'>
        <div className='container'>
          <Link className='navbar-brand fw-bold' to='/'>E-Commerce</Link>
          <button className='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
            <span className='navbar-toggler-icon'></span>
          </button>
          <div className='collapse navbar-collapse' id='navbarNav'>
            <ul className='navbar-nav me-auto mb-lg-0'>
              <li className='nav-item'>
                <Link className='nav-link' to='/'>Home</Link>
              </li>
              {
                !isLoggedIn && (
                  <>
                    <li className='nav-item'>
                      <Link className='nav-link' to='/login'>Login</Link>
                    </li>
                    <li className='nav-item'>
                      <Link className='nav-link' to='/signup'>Signup</Link>
                    </li>
                  </>
                )
              }

              {
                isLoggedIn && user?.userRole === 'admin' && (
                  <>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/orders'>All Orders</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/add-product'>Add Product</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/add-inventory'>Add Inventory</Link> 
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/view-inventory'>View Inventory</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/update-product'>Update Product</Link>
                    </li>
                  </>
                )
              }

              {
                isLoggedIn && user?.userRole === 'customer' && (
                  <>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/place-order'>Place Order</Link>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/orders'>My Orders</Link>
                    </li>
                  </>
                )
              }

              {
                isLoggedIn && (
                  <>
                    <li className='nav-item'>
                       <button className='btn btn-link nav-link text-white' onClick={handleLogout}>Logout</button>
                    </li>
                  </>
                )
              }
            </ul>

            {
              isLoggedIn && user && (
                <span className='navbar-text me-3'>Welcome, {user.userName} ({user.userRole})</span>
              )
            }
          </div>
        </div>

      </div>
    </nav>
  )
}


function App() {

  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path='/' element={<ViewAllProducts />} />
        <Route path='/view-inventory' element={<ViewAllInventory />} />
        <Route path='/orders' element={<GetAllOrders />} />

        <Route path='/add-product' element={<AddProductForm />} />
        <Route path='/add-inventory' element={<NewInventory />} />

        <Route path='/signup' element={<UserSignupForm />} />
        <Route path='/login' element={<UserLoginForm />} />

        <Route path='/place-order/:productId' element={<PlaceOrderForm />} />
        <Route path='/update-product/:prdId' element={<UpdateProductForm />} />
      </Routes>
    </div>
  )
}

export default App
