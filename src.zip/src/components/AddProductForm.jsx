import React, { useRef, useState } from 'react'
import { addProduct } from '../services/productService';

const getImageUrlError = (imageUrl) => {
    if (!imageUrl.trim()) {
        return 'Product image URL is required';
    }
    try {
        const url = new URL(imageUrl);
        if (url.protocol !== 'http:' && url.protocol !== 'https:') {
            return 'Image URL must use http or https';
        }
    } catch {
        return 'Enter a valid image URL';
    }
    return '';
};


function AddProductForm() {

    const productNameRef = useRef();
    const productDescriptionRef = useRef();
    const priceRef = useRef();
    const categoryRef = useRef();
    const brandRef = useRef();
    const imageUrlRef = useRef();

    const [errors, setErrors] = useState({});



    const handleBlur = (name, updateErrors = true) => {
        let error = '';

        switch (name) {
            case 'productName':
                if (!productNameRef.current.value.trim()) error = 'Product name is required';
                break;
            case 'productDescription':
                if (!productDescriptionRef.current.value.trim()) error = 'Description is required';
                break;
            case 'price':
                if (!priceRef.current.value.trim() || isNaN(priceRef.current.value) || Number(priceRef.current.value) <= 0) {
                    error = 'Valid price is required';
                }
                break;
            case 'category':
                if (!categoryRef.current.value.trim()) error = 'Category is required';
                break;
            case 'brand':
                if (!brandRef.current.value.trim()) error = 'Brand is required';
                break;
            case 'imageUrl':
                error = getImageUrlError(imageUrlRef.current.value);
                break;
            default:
                break;
        }
        if (updateErrors) {
            setErrors(prev => ({ ...prev, [name]: error }));
        }
        return error;
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const fieldNames = ['productName', 'productDescription', 'price', 'category', 'brand', 'imageUrl'];
        const validationErrors = {};
        fieldNames.forEach(name => {
            const error = handleBlur(name, false);
            if (error) validationErrors[name] = error;
        });
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
        setErrors({});

        const product = {
            productName: productNameRef.current.value,
            productDescription: productDescriptionRef.current.value,
            price: Number(priceRef.current.value),
            category: categoryRef.current.value,
            brand: brandRef.current.value,
            imageUrl: imageUrlRef.current.value
        }
        const productAdded = await addProduct(product);
        console.log('Product Added Successfully!');
        e.target.reset();
        setErrors({});
    }


    return (
        <>
            <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
                <div className="col-md-7 col-lg-6">
                    <div className="card shadow-lg border-0">
                        <div className="card-header bg-success text-white text-center py-3 rounded-top">
                            <h2 className="mb-0">Add Product</h2>
                        </div>
                        <div className="card-body p-4">
                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <label className='form-label' htmlFor='productName'>Product Name:</label>
                                    <input
                                        type="text"
                                        id='productName'
                                        name='productName'
                                        className={`form-control ${errors.productName ? 'is-invalid' : ''}`}
                                        ref={productNameRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.productName && <div className="invalid-feedback">{errors.productName}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className='form-label' htmlFor='productDescription'>Product Description:</label>
                                    <input
                                        type="text"
                                        id='productDescription'
                                        name='productDescription'
                                        className={`form-control ${errors.productDescription ? 'is-invalid' : ''}`}
                                        ref={productDescriptionRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.productDescription && <div className="invalid-feedback">{errors.productDescription}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className='form-label' htmlFor='price'>Product Price:</label>
                                    <input
                                        type="text"
                                        id='price'
                                        name='price'
                                        className={`form-control ${errors.price ? 'is-invalid' : ''}`}
                                        ref={priceRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.price && <div className="invalid-feedback">{errors.price}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className='form-label' htmlFor='category'>Product Category:</label>
                                    <input
                                        type="text"
                                        id='category'
                                        name='category'
                                        className={`form-control ${errors.category ? 'is-invalid' : ''}`}
                                        ref={categoryRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.category && <div className="invalid-feedback">{errors.category}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className='form-label' htmlFor='brand'>Product Brand:</label>
                                    <input
                                        type="text"
                                        id='brand'
                                        name='brand'
                                        className={`form-control ${errors.brand ? 'is-invalid' : ''}`}
                                        ref={brandRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.brand && <div className="invalid-feedback">{errors.brand}</div>}
                                </div>

                                <div className="mb-3">
                                    <label className='form-label' htmlFor='imageUrl'>Product Image URL:</label>
                                    <input
                                        type="url"
                                        id='imageUrl'
                                        name='imageUrl'
                                        className={`form-control ${errors.imageUrl ? 'is-invalid' : ''}`}
                                        placeholder="https://example.com/image.jpg"
                                        ref={imageUrlRef}
                                        onBlur={(e) => {
                                            handleBlur(e.target.name)
                                        }}
                                    />
                                    {errors.imageUrl && <div className="invalid-feedback">{errors.imageUrl}</div>}
                                </div>
                                <button type="submit" className="btn btn-success w-100 mt-3">Add Product</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddProductForm