import React, { useState, useEffect, useContext } from 'react'
import { AuthContext } from '../context/AuthContext';
import { getOrders, cancelOrder, deliverOrder } from '../services/orderService';

function GetAllOrders() {
    const [orders, setOrders] = useState([]);
    const { user } = useContext(AuthContext);
    const [cancel, setCancel] = useState(false);
    const [deliver, setDeliver] = useState(false);

    useEffect(
        () => {
            // Fetch all orders from the API
            const fetchOrders = async () => {
                const result = await getOrders();
                setOrders(result);
            }
            fetchOrders()
        }, [cancel, deliver]
    )

    const filteredOrders = user && user.userRole === 'customer' ?
        orders.filter(order => String(order.customerId) === String(user.userId))
        : orders;

    const handleCancelOrder = async (orderId) => {
        if (await cancelOrder(orderId)) {
            setCancel(true);
            alert('Order has been cancelled successfully');
        }
    }

    const handleDeliverOrder = async (orderId) => {
        if (await deliverOrder(orderId)) {
            setDeliver(true);
            alert('Order has been Delivered successfully');
        }
    }


    return (
        <div className="container mt-4">
            <h2 className="mb-4">All Orders</h2>
            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>Order ID</th>
                        <th>Customer ID</th>
                        <th>Product ID</th>
                        <th>Quantity</th>
                        <th>Order Amount</th>
                        <th>Order Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredOrders.map(order => (
                        <tr key={order.orderId}>
                            <td>{order.orderId}</td>
                            <td>{order.customerId}</td>
                            <td>{order.productId}</td>
                            <td>{order.quantity}</td>
                            <td>{order.orderAmount}</td>
                            <td>{order.orderDate}</td>
                            <td>{order.status}</td>
                            {user && user.userRole === 'customer' && (
                                <td>
                                    <button className="btn btn-danger btn-sm" disabled={order.status === 'Delivered' || order.status === 'Cancelled'} onClick={() => handleCancelOrder(order.orderId)}>Cancel</button>
                                </td>
                            )}
                            {user && user.userRole === 'admin' && (
                                <td>
                                    <button className="btn btn-info btn-sm" disabled={order.status === 'Delivered' || order.status === 'Cancelled'} onClick={() => handleDeliverOrder(order.orderId)}>Delivered</button>
                                </td>
                            )}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default GetAllOrders