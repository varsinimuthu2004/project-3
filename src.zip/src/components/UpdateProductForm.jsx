import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProductById, updateProduct } from "../services/productService";

function UpdateProductForm() {

    const [product, setProduct] = useState({});
    const { prdId } = useParams();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(prdId);
        let imageUrlValue;
        if (product.imageUrl instanceof File) {
            // If a new file is selected, send its name (or handle file upload as needed)
            imageUrlValue = product.imageUrl.name;
            console.log(product.imageUrl.name);
            console.log(imageUrlValue);

            // If your backend expects the file itself, you need to send FormData
        } else {
            // Otherwise, send the existing image URL string
            imageUrlValue = product.imageUrl;
        }
        const updatedProduct = {
            productId: prdId,
            productName: e.target.productName.value,
            productDescription: e.target.productDescription.value,
            price: e.target.price.value,
            category: e.target.category.value,
            brand: e.target.brand.value,
            imageUrl: imageUrlValue,
        };

        setProduct(await updateProduct(updatedProduct));
        navigate('/')
    }

    useEffect(
        ()=> {
            const fetchProduct = async ()=> {
                const productData = await getProductById(prdId);
                setProduct(productData);
            }
            fetchProduct();
        },[prdId]
    )


    return (
        <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
            <div className="col-md-7 col-lg-6">
                <div className="card shadow-lg border-0">
                    <div className="card-header bg-info text-white text-center py-3 rounded-top">
                        <h2 className="mb-0">Update Product</h2>
                    </div>
                    <div className="card-body p-4">
                        <form onSubmit={handleSubmit} noValidate>
                            <div className="mb-3">
                                <label className="form-label">Product Name</label>
                                <input type="text" id="productName" name="productName" className="form-control" onChange={(e) => setProduct({ ...product, productName: e.target.value })} value={product?.productName || ''} />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Description</label>
                                <textarea id="productDescription" name="productDescription" className="form-control" onChange={(e) => setProduct({ ...product, productDescription: e.target.value })} value={product?.productDescription || ''}></textarea>
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Price</label>
                                <input type="number" id="price" name="price" className="form-control" onChange={(e) => setProduct({ ...product, price: e.target.value })} value={product?.price || ''} />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Category</label>
                                <input type="text" id="category" name="category" className="form-control" onChange={(e) => setProduct({ ...product, category: e.target.value })} value={product?.category || ''} />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Brand</label>
                                <input type="text" id="brand" name="brand" className="form-control" onChange={(e) => setProduct({ ...product, brand: e.target.value })} value={product?.brand || ''} />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Product Image</label>
                                <input
                                    type="file"
                                    id="imageUrl"
                                    name="imageUrl"
                                    className="form-control"
                                    onChange={(e) => setProduct({ ...product, imageUrl: e.target.files[0] })}

                                />

                                {product?.imageUrl && (
                                    product.imageUrl instanceof File ? (
                                        <img
                                            src={URL.createObjectURL(product.imageUrl)}
                                            alt="Product"
                                            style={{ width: '120px', height: '120px', objectFit: 'cover', marginTop: '10px', borderRadius: '8px' }}
                                        />
                                    ) : (
                                        <img
                                            src={'/' + product.imageUrl}
                                            //src={product.imageUrl}
                                            alt="Product"
                                            style={{ width: '120px', height: '120px', objectFit: 'cover', marginTop: '10px', borderRadius: '8px' }}
                                        />
                                    )
                                )}
                            </div>
                            <button type="submit" className="btn btn-info w-100 mt-3">Update Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UpdateProductForm