import { useContext, useState, useEffect } from "react"
import { useNavigate } from "react-router-dom";
import { login } from "../services/userService";
import { AuthContext } from "../context/AuthContext";

function UserLoginForm() {

    const [form, setForm] = useState({})
    const [fieldErrors, setFieldErrors] = useState({});
    const [error, setError] = useState(false);
    const [success, setSuccess] = useState(false);
    const [user, setUser] = useState({});

    const navigate = useNavigate();

    const { ctxLogin, user: loggedInUser } = useContext(AuthContext);

    const isLoggedOut = loggedInUser === null;


    useEffect(
        () => {
            setForm({});
            setFieldErrors({});
            setError(false);
            setSuccess(false);
            setUser({});
        },[isLoggedOut]
    )

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]: value
        });
    }

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setFieldErrors({
            ...fieldErrors,
            [name]: getFieldError(name, value)
        });
    }

    const getFieldError = (name, value) => {
        switch (name) {

            case 'userEmail':
                if (!value.trim()) return 'Email is required.';
                if (!/^\S+@\S+\.\S+$/.test(value)) return 'Email is invalid.';
                break;
            case 'userPassword':
                if (!value) return 'Password is required.';
                if (value.length < 6) return 'Password must be at least 6 characters.';
                break;
            default:
                return '';
        }
        return '';
    };

    // Validate all fields at once
    const validateFields = () => {
        const errors = {};
        Object.keys(form).forEach((key) => {
            const error = getFieldError(key, form[key]);
            if (error) errors[key] = error;
        });
        return errors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const errors = validateFields();
        setFieldErrors(errors);
        if (Object.keys(errors).length > 0) {
            setError('Please fix the errors below.');
            return;
        }
        try {
            setSuccess(true);
            setError(false);
            const result = await login(form.userEmail, form.userPassword);
            if (result.success && result.user && result.user.userId) {
                ctxLogin(result.user)
                setUser(result.user);
                setSuccess(true);
                setError(false);
                navigate('/')
            }
            else {
                setError(true);
                setSuccess(false);
                setUser(null)
            }
        }
        catch (error) {
            setError('An unexpected error occurred.');
            setSuccess(false);
        }
    }


    return (
        <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
            <div className="col-md-6 col-lg-5">
                <div className="card shadow-lg border-0">
                    <div className="card-header bg-primary text-white text-center py-3 rounded-top">
                        <h2 className="mb-0">Login</h2>
                    </div>
                    <div>
                        <form onSubmit={handleSubmit}>
                            {success && user && (
                                <div className="alert alert-success" role="alert">
                                    Logged in successfully: {user.userId}
                                </div>
                            )}
                            {error && (
                                <div className="alert alert-danger" role="alert">
                                    Invalid Credentials. {error}
                                </div>
                            )}

                            <div className="mb-3">
                                <label className="form-label">Email:</label>
                                <input
                                    type="email"
                                    className={`form-control ${fieldErrors.userEmail ? 'is-invalid' : ''}`}
                                    name="userEmail"
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                    value={form.userEmail}
                                />
                                {fieldErrors.userEmail && <div className='invalid-feedback'>{fieldErrors.userEmail}</div>}
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Password:</label>
                                <input
                                    type="password"
                                    className={`form-control ${fieldErrors.userPassword ? 'is-invalid' : ''}`}
                                    name="userPassword"
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                    value={form.userPassword}
                                />
                                {fieldErrors.userPassword && <div className='invalid-feedback'>{fieldErrors.userPassword}</div>}
                            </div>
                            <button type="submit" className="btn btn-warning w-100 mt-3">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserLoginForm