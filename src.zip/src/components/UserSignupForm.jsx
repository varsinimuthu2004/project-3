import { useState } from "react";
import User from "../model/User";
import { registerUser } from "../services/userService";

function UserSignupForm() {

    const [form, setForm] = useState({ userId: '', userName: '', userEmail: '', userPassword: '', userRole: 'customer' });

    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const [showError, setShowError] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);
    const [fieldErrors, setFieldErrors] = useState({});

    const getFieldError = (name, value) => {
        switch (name) {
            case 'userName':
                if (!value.trim()) return 'User Name is required.';
                if (value.length < 3) return 'User Name must be at least 3 characters.';
                break;
            case 'userEmail':
                if (!value.trim()) return 'Email is required.';
                if (!/^\S+@\S+\.\S+$/.test(value)) return 'Email is invalid.';
                break;
            case 'userPassword':
                if (!value) return 'Password is required.';
                if (value.length < 6) return 'Password must be at least 6 characters.';
                break;
            case 'userRole':
                if (!value) return 'Role is required.';
                break;
            default:
                return '';
        }
        return '';
    };

    // Validate all fields at once
    const validateFields = () => {
        const errors = {};
        Object.keys(form).forEach((key) => {
            const error = getFieldError(key, form[key]);
            if (error) errors[key] = error;
        });
        return errors;
    };


    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(
            {
                ...form, // If I dont write this line, previous data will be lost. It retains all previous data
                [name]: value
            }
        )
    }

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setFieldErrors({
            ...fieldErrors,
            [name]: getFieldError(name, value)
        });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        setShowError(false);
        setShowSuccess(false);
        const errors = validateFields();
        setFieldErrors(errors);
        if (Object.keys(errors).length > 0) {
            setError('Please fix the errors below.');
            setShowError(true);
            return;
        }
        try {
            const user = new User('', form.userName, form.userEmail, form.userPassword, form.userRole);
            const fetchUser = await registerUser(user);
            setSuccess(`User registered successfully. UserName ${fetchUser.userName}`);
            setShowSuccess(true);
            setForm({
                userName: '',
                userEmail: '',
                userPassword: '',
                userRole: 'customer'
            });
            setFieldErrors({});
        } catch (error) {
            setError(`An error occurred during signup. ${error.message}`);
            setShowError(true);
        }
    }

    return (
        <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
            <div className="row w-100 justify-content-center">
                <div className="col-md-6 col-lg-5">
                    <div className="card shadow-lg border-0">
                        <div className="card-header bg-primary text-white text-center py-3 rounded-top">
                            <h2 className="mb-0">Sign Up</h2>
                        </div>
                        <div className="card-body p-4">
                            {showError && error && (
                                <div className="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                                    {error}
                                    <button type="button" className="btn-close" aria-label="Close" onClick={() => setShowError(false)}></button>
                                </div>
                            )}
                            {showSuccess && success && (
                                <div className="alert alert-success alert-dismissible fade show mt-3" role="alert">
                                    {success}
                                    <button type="button" className="btn-close" aria-label="Close" onClick={() => setShowSuccess(false)}></button>
                                </div>
                            )}
                            <form onSubmit={handleSubmit}>
                                <div className='mb-3'>
                                    <label className='form-label'>User Name:</label>
                                    <input
                                        type='text'
                                         className={`form-control ${fieldErrors.userName ? 'is-invalid' : ''}`}
                                        name='userName'
                                        value={form.userName}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {fieldErrors.userName && <div className='invalid-feedback'>{fieldErrors.userName}</div>}
                                </div>

                                <div className='mb-3'>
                                    <label className='form-label'>User Email:</label>
                                    <input
                                        type='email'
                                        className={`form-control ${fieldErrors.userEmail ? 'is-invalid' : ''}`}
                                        name='userEmail'
                                        value={form.userEmail}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {fieldErrors.userEmail && <div className='invalid-feedback'>{fieldErrors.userEmail}</div>}
                                </div>

                                <div className='mb-3'>
                                    <label className='form-label'>Password:</label>
                                    <input
                                        type='password'
                                        className={`form-control ${fieldErrors.password ? 'is-invalid' : ''}`}
                                        name='userPassword'
                                        value={form.userPassword}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {fieldErrors.password && <div className='invalid-feedback'>{fieldErrors.password}</div>}
                                </div>

                                <div className='mb-3'>
                                    <label className='form-label'>User Role:</label>
                                    <select
                                        className='form-control'
                                        name='userRole'
                                        value={form.userRole}
                                        onChange={handleChange}
                                        onBlur={handleBlur}>
                                        <option value='customer'>Customer</option>
                                        <option value='admin'>Admin</option>
                                    </select>
                                    {fieldErrors.userRole && <div className='invalid-feedback'>{fieldErrors.userRole}</div>}
                                </div>
                                <button type="submit" className='btn btn-primary w-100 mt-3'>Register</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserSignupForm