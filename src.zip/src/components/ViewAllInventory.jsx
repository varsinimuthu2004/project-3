import React, { useState, useEffect } from 'react'
import { getAllInventoryItems, updateInventory } from '../services/inventoryService';


const ViewAllInventory = () => {

    const [inventoryItems, setInventoryItems] = useState([]);
    const [stock, setStock] = useState({});

    const fetchInventoryItems = async () => {
        const items = await getAllInventoryItems();
        setInventoryItems(items);
    }

    useEffect(
        () => {
            fetchInventoryItems();
        }, []
    )

    const handleUpdateStock = async (productId) => {
        const newStock = Number(stock[productId]);
        console.log(`Updating Stock for product ${productId} to ${newStock}`);

        if (!isNaN(newStock)) {
            try {
                console.log(productId + ' ' + newStock);
                const result = await updateInventory(productId, newStock);
                //please create the above method in respective Service layer Guys. 
                alert(result);
                const items = await getAllInventoryItems();
                setInventoryItems(items);
            }
            catch (error) {
                console.error("Failed to update inventory:", error);
                alert("Failed to update inventory. Please try again.");
            }
        }

    }


    return (
        <>
            <div className="container mt-5">
                <h2 className="mb-4">All Inventory Items</h2>
                <table className="table table-bordered table-hover align-middle text-center">
                    <thead className="table-primary">
                        <tr>
                            <th>Inventory ID</th>
                            <th>Product Id</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {inventoryItems.map(item => (
                            <tr key={item.inventoryId}>
                                <td>{item.inventoryId}</td>
                                <td>{item.productId}</td>
                                <td>{item.stock}</td>
                                <td><input type="number" value={stock[item.productId] ?? item.stock}
                                    onChange={e =>
                                        setStock(prev => ({
                                            ...prev,
                                            [item.productId]: e.target.value
                                        }))
                                    } id={`stock-input-${item.productId}`} /></td>
                                <td>
                                    <button className="btn btn-warning btn-sm me-2" onClick={() => handleUpdateStock(item.productId)}>Update Stock</button>
                                    {/* <button className="btn btn-danger btn-sm" onClick={() => handleDelete(item.inventoryId)}>Delete</button> */}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default ViewAllInventory