import { createContext, useEffect, useState } from "react";

export const AuthContext = createContext();

export function AuthProvider({children}) {

    const [isLoggedIn, setIsLoggedIn] = useState(() => {
        const stored = localStorage.getItem('isLoggedIn');
        return stored === 'true';
    });

    const [user, setUser] = useState(
        () => {
            const stored = localStorage.getItem('user');
            return stored ? JSON.parse(stored) : null;
        }
    );

    useEffect(
        () => {
            localStorage.setItem('isLoggedIn', isLoggedIn)
            localStorage.setItem('user',user?JSON.stringify(user):'')
        },[isLoggedIn, user]
    )

    const ctxLogin = (userData) => {
        setIsLoggedIn(true);
        setUser(userData);
    }

    const ctxLogout = () => {
        setIsLoggedIn(false);
        setUser(null);
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('user');
    }

    return (
        <AuthContext.Provider value={{ isLoggedIn, user, ctxLogin, ctxLogout }}>
            {children}
        </AuthContext.Provider>
    )
}