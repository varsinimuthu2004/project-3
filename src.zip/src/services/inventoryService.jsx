import axios from "axios";

export const INVENTORY_API_URL = "http://localhost:8082/inventory";
export const PRODUCT_API_URL = "http://localhost:8081/products";

export const getAllInventoryItems = async () => {
    const response = await axios.get(`${INVENTORY_API_URL}/all`);
    return response.data;
}

export const updateInventory = async (productId, quantity) => {
    const response = await axios.put(`${INVENTORY_API_URL}/update`, { productId, quantity });
    return response.data;
}

export const getProductsNotInStock = async () => {
    const [productResponse, inventoryResponse] = await Promise.all([
        axios.get(PRODUCT_API_URL),
        axios.get(`${INVENTORY_API_URL}/all`)
    ]);

    const products = productResponse.data;
    const inventory = inventoryResponse.data;

    return products.filter(product => !inventory.some(item => String(item.productId) === String(product.productId)));
}

export const createInventoryItem = async (inventoryItem) => {
    const response = await axios.post(`${INVENTORY_API_URL}/add`, inventoryItem);
    return response.data;
}

// Asynchronous function that deletes an inventory item from the database
export const deleteInventoryItem = async (id) => {
    // Make HTTP DELETE request with inventory item ID in URL path
    const response = await fetch(`${INVENTORY_API_URL}/delete/${id}`, {
        // Use DELETE method to remove the inventory resource
        method: 'DELETE'
    });
    // Check if deletion failed and throw error for debugging
    if (!response.ok)
        throw new Error('Failed to Delete Inventory Item');
    // Parse and return the JSON response confirming the deletion
    return response.json();
};

