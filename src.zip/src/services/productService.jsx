import axios from 'axios'

export const PRODUCT_API_URL = 'http://localhost:8081/products'

export const getAllProducts = async () => {
    try {
        const response = await axios.get(PRODUCT_API_URL)
        return response.data

    }
    catch (error) {
        console.error('Error fetching products:', error)
        throw error;
    }
}

export const getStockByProductId = async (productId) => {
    try {
        const response = await axios.get(`${PRODUCT_API_URL}/stock/${productId}`)
        return response.data
    }
    catch (error) {
        console.error('Error fetching stock for product:', error)
        throw error;
    }
}

export const addProduct = async(product)=> {
    try {
        const response = await axios.post(`${PRODUCT_API_URL}/add`, product);
        return response.data;
    } catch (error) {
        console.error('Error adding product ', error);
        throw error;
    }
}


// Asynchronous function that updates an existing product with new information
export const updateProduct = async (updatedProduct) => {
    // Try-catch block for error handling during product update operation
    try {
        // Make HTTP PUT request to update endpoint with complete updated product data
        const response = await axios.put(`${PRODUCT_API_URL}/update`, updatedProduct);
        // Return response data containing the updated product information
        return response.data;
    } catch (error) {
        // Log error to console for debugging when product update fails
        console.error('Error updating product', error);
        // Re-throw error to propagate to calling component for error handling
        throw error;
    }
};

// Asynchronous function that retrieves a specific product by its unique identifier
export const getProductById = async (productId) => {
    try {
        const response = await axios.get(`${PRODUCT_API_URL}/${productId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching product by ID', error);
        throw error;
    }
};

// Asynchronous function that deletes a product from the database using its unique ID
export const deleteProduct = async (productId) => {
    // Try-catch block for error handling during product deletion
    try {
        // Make HTTP DELETE request to delete endpoint with product ID in URL path
        const response = await axios.delete(`${PRODUCT_API_URL}/delete/${productId}`);
        // Return response data confirming successful deletion or operation result
        return response.data;
    } catch (error) {
        // Log error to console for debugging when product deletion fails
        console.error('Error deleting product', error);
        // Re-throw error to allow calling component to handle deletion failure
        throw error;
    }
};