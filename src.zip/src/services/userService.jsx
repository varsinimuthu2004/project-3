import axios from "axios";

export const USER_API_URL = 'http://localhost:8083/users';

export const registerUser = async (user) => {
    try {
        const response = await axios.post(`${USER_API_URL}/register`, {
            userName: user.userName,
            userEmail: user.userEmail,
            userPassword: user.userPassword,
            userRole: user.userRole
        });
        return response.data;
    }
    catch (error) {
        console.error('Error Registering the User - ', error);
        throw error;
    }
}

export const login = async (userEmail, userPassword) => {
    try {
        const response = await axios.post(`${USER_API_URL}/validate`, {
            userEmail: userEmail,
            userPassword: userPassword
        });
        return { success: true, user: response.data };
    }
    catch (error) {
        console.error('Error Logging in the User - ', error);
        return { success: false, user: null, error: error.response ? error.response.data : 'An Error Occured' }
    }
}