import React, { useContext } from 'react';
import './App.css';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import UserLoginForm from './components/UserLoginForm';
import UserSignupForm from './components/UserSignupForm';
import ProjectOwnerDashboard from './components/ProjectOwnerDashboard';
import CreateProjectForm from './components/CreateProjectForm';
import CreateIssueForm from './components/CreateIssueForm';
import IssueDetail from './components/IssueDetail';
import EditIssueForm from './components/EditIssueForm';
import AssigneeDashboard from './components/AssigneeDashboard';
import AssigneeIssueDetail from './components/AssigneeIssueDetail';

function RootRedirect() {
    const { isLoggedIn, user } = useContext(AuthContext);
    if (!isLoggedIn || !user) {
        return <Navigate to="/login" replace />;
    }
    if (user.role === 'PROJECT_OWNER') {
        return <Navigate to="/dashboard" replace />;
    }
    return <Navigate to="/assignee-dashboard" replace />;
}

function ProtectedRoute({ children, allowedRole }) {
    const { isLoggedIn, user } = useContext(AuthContext);
    if (!isLoggedIn || !user) {
        return <Navigate to="/login" replace />;
    }
    if (allowedRole && user.role !== allowedRole) {
        return <RootRedirect />;
    }
    return children;
}

function App() {
    return (
        <div className="App">
            <Routes>
                {/* Public Auth Routes */}
                <Route path="/login" element={<UserLoginForm />} />
                <Route path="/signup" element={<UserSignupForm />} />

                {/* Project Owner Routes */}
                <Route
                    path="/dashboard"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <ProjectOwnerDashboard />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/create-project"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <CreateProjectForm />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/create-issue"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <CreateIssueForm />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/issue-details/:id"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <IssueDetail />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/edit-issue/:id"
                    element={
                        <ProtectedRoute allowedRole="PROJECT_OWNER">
                            <EditIssueForm />
                        </ProtectedRoute>
                    }
                />

                {/* Assignee Routes */}
                <Route
                    path="/assignee-dashboard"
                    element={
                        <ProtectedRoute allowedRole="ASSIGNEE">
                            <AssigneeDashboard />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/assignee-issue-detail/:id"
                    element={
                        <ProtectedRoute allowedRole="ASSIGNEE">
                            <AssigneeIssueDetail />
                        </ProtectedRoute>
                    }
                />

                {/* Default Root */}
                <Route path="/" element={<RootRedirect />} />
                <Route path="*" element={<RootRedirect />} />
            </Routes>
        </div>
    );
}

export default App;
