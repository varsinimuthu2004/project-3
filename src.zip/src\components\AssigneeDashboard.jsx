import React, { useContext, useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssuesByAssigneeId } from "../services/issueService";

function AssigneeDashboard() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issues, setIssues] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [loading, setLoading] = useState(true);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const fetchAssigneeIssues = async () => {
            try {
                setLoading(true);
                const assignedIssues = await getIssuesByAssigneeId(user.userId);
                setIssues(Array.isArray(assignedIssues) ? assignedIssues : []);
            } catch (err) {
                console.error("Error loading assignee issues:", err);
                setIssues([]);
            } finally {
                setLoading(false);
            }
        };

        fetchAssigneeIssues();
    }, [user]);

    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        try {
            const parts = dateStr.split('-');
            if (parts.length === 3) {
                return `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
            return dateStr;
        } catch {
            return dateStr;
        }
    };

    const getPriorityBadgeClass = (priority) => {
        switch (priority) {
            case 'HIGH':
                return 'badge-priority-high';
            case 'MEDIUM':
                return 'badge-priority-medium';
            case 'LOW':
                return 'badge-priority-low';
            default:
                return 'badge-priority-medium';
        }
    };

    // RegEx match between search text & summary/description
    const filteredIssues = useMemo(() => {
        if (!searchText.trim()) return issues;
        try {
            const regex = new RegExp(searchText.trim(), 'i');
            return issues.filter(i => {
                const inSum = i.summary && regex.test(i.summary);
                const inDesc = i.description && regex.test(i.description);
                return inSum || inDesc;
            });
        } catch {
            const term = searchText.toLowerCase();
            return issues.filter(i => {
                return (
                    (i.summary && i.summary.toLowerCase().includes(term)) ||
                    (i.description && i.description.toLowerCase().includes(term))
                );
            });
        }
    }, [issues, searchText]);

    const todoIssues = filteredIssues.filter(i => i.status === 'TO_DO');
    const devIssues = filteredIssues.filter(i => i.status === 'DEVELOPMENT');
    const testIssues = filteredIssues.filter(i => i.status === 'TESTING');
    const completedIssues = filteredIssues.filter(i => i.status === 'COMPLETED' || i.status === 'DONE');

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Antonia Christie')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Antonia Christie');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Antonia Christie"}</h6>
                        <small className="text-muted">{user?.emailId || "antonia@xyz.com"}</small>
                    </div>

                    <div className="stats-box text-center py-2 mb-4">
                        <div className="stat-number fw-bold">{issues.length}</div>
                        <div className="stat-label small">Issues Assigned</div>
                    </div>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                {/* Header */}
                <header className="dashboard-header d-flex align-items-center justify-content-between">
                    <div className="search-bar-container">
                        <input
                            type="text"
                            className="form-control search-input"
                            placeholder="Search issue by summary or description"
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                        />
                    </div>
                    <div className="header-title-bar">
                        <span>Issue Tracking System</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-warning" role="status"></div>
                            <p className="mt-2 text-muted">Loading assigned issues...</p>
                        </div>
                    ) : (
                        <div className="kanban-board-container row g-3">
                            {/* TO DO Column */}
                            <div className="col-md-3">
                                <div className="kanban-column-card">
                                    <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                        <span className="column-title">📋 TO DO</span>
                                        <span className="badge badge-column-count badge-todo">{todoIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards-wrapper p-2">
                                        {todoIssues.map(issue => (
                                            <AssigneeIssueCard
                                                key={issue.id}
                                                issue={issue}
                                                user={user}
                                                formatDate={formatDate}
                                                getPriorityBadgeClass={getPriorityBadgeClass}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* DEVELOPMENT Column */}
                            <div className="col-md-3">
                                <div className="kanban-column-card">
                                    <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                        <span className="column-title">&lt;/&gt; DEVELOPMENT</span>
                                        <span className="badge badge-column-count badge-dev">{devIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards-wrapper p-2">
                                        {devIssues.map(issue => (
                                            <AssigneeIssueCard
                                                key={issue.id}
                                                issue={issue}
                                                user={user}
                                                formatDate={formatDate}
                                                getPriorityBadgeClass={getPriorityBadgeClass}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* TESTING Column */}
                            <div className="col-md-3">
                                <div className="kanban-column-card">
                                    <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                        <span className="column-title">🧪 TESTING</span>
                                        <span className="badge badge-column-count badge-testing">{testIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards-wrapper p-2">
                                        {testIssues.map(issue => (
                                            <AssigneeIssueCard
                                                key={issue.id}
                                                issue={issue}
                                                user={user}
                                                formatDate={formatDate}
                                                getPriorityBadgeClass={getPriorityBadgeClass}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* COMPLETED Column */}
                            <div className="col-md-3">
                                <div className="kanban-column-card">
                                    <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                        <span className="column-title">☑ COMPLETED</span>
                                        <span className="badge badge-column-count badge-completed">{completedIssues.length}</span>
                                    </div>
                                    <div className="kanban-cards-wrapper p-2">
                                        {completedIssues.map(issue => (
                                            <AssigneeIssueCard
                                                key={issue.id}
                                                issue={issue}
                                                user={user}
                                                formatDate={formatDate}
                                                getPriorityBadgeClass={getPriorityBadgeClass}
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
}

function AssigneeIssueCard({ issue, user, formatDate, getPriorityBadgeClass }) {
    return (
        <div className="issue-card bg-white p-3 rounded mb-2 shadow-sm">
            <div className="d-flex justify-content-between align-items-center mb-1">
                <span className="issue-id small text-muted fw-semibold">Id: {issue.id}</span>
                <span className="issue-date small text-muted">{formatDate(issue.createdOn)}</span>
            </div>
            <Link
                to={`/assignee-issue-detail/${issue.id}`}
                className="issue-summary-link d-block mb-1 fw-bold text-dark text-decoration-none"
            >
                {issue.summary}
            </Link>
            <p className="issue-desc-text small text-muted mb-3">
                {issue.description || 'No description provided.'}
            </p>
            <div className="d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center">
                    <img
                        src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Assignee')}
                        alt={user?.name || "Assignee"}
                        className="assignee-avatar-sm me-2"
                        onError={(e) => {
                            e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Assignee');
                        }}
                    />
                    <span className="small text-muted">{user?.name}</span>
                </div>
                <span className={`badge ${getPriorityBadgeClass(issue.priority)}`}>
                    {issue.priority}
                </span>
            </div>
        </div>
    );
}

export default AssigneeDashboard;
