import React, { useContext, useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssueById, updateIssue, getIssuesByAssigneeId } from "../services/issueService";

function AssigneeIssueDetail() {
    const { id } = useParams();
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issue, setIssue] = useState(null);
    const [selectedStatus, setSelectedStatus] = useState('');
    const [originalStatus, setOriginalStatus] = useState('');
    const [assignedCount, setAssignedCount] = useState(0);

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [successMsg, setSuccessMsg] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const fetchIssue = async () => {
            try {
                setLoading(true);
                const issueData = await getIssueById(id);
                setIssue(issueData);
                if (issueData?.status) {
                    setSelectedStatus(issueData.status);
                    setOriginalStatus(issueData.status);
                }

                const myIssues = await getIssuesByAssigneeId(user.userId);
                setAssignedCount(myIssues?.length || 0);
            } catch (err) {
                console.error("Error fetching issue for assignee:", err);
                setErrorMsg("Failed to load issue details.");
            } finally {
                setLoading(false);
            }
        };

        fetchIssue();
    }, [id, user]);

    const handleStatusChange = (e) => {
        setSelectedStatus(e.target.value);
        setSuccessMsg('');
        setErrorMsg('');
    };

    // "When the status is changed using the drop-down, the 'Save Updates' button becomes enabled."
    const isSaveEnabled = selectedStatus !== '' && selectedStatus !== originalStatus;

    const handleSaveUpdates = async () => {
        if (!isSaveEnabled) return;
        try {
            setSaving(true);
            setErrorMsg('');
            setSuccessMsg('');

            const updatePayload = {
                ...issue,
                status: selectedStatus
            };

            await updateIssue(id, updatePayload);
            setOriginalStatus(selectedStatus);
            setIssue(prev => ({ ...prev, status: selectedStatus }));
            setSuccessMsg('Issue status updated successfully!');
        } catch (err) {
            setErrorMsg(err.message || 'Failed to update issue status.');
        } finally {
            setSaving(false);
        }
    };

    const renderTags = (tagsStr) => {
        if (!tagsStr) return null;
        const tagList = tagsStr.split(/[\s,]+/).filter(Boolean);
        return tagList.map((tag, idx) => (
            <span key={idx} className="badge bg-success me-1 text-white fw-normal">
                {tag.startsWith('#') ? tag : `#${tag}`}
            </span>
        ));
    };

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Antonia Christie')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Antonia Christie');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Antonia Christie"}</h6>
                        <small className="text-muted">{user?.emailId || "antonia@xyz.com"}</small>
                    </div>

                    <div className="stats-box text-center py-2 mb-4">
                        <div className="stat-number fw-bold">{assignedCount}</div>
                        <div className="stat-label small">Issues Assigned</div>
                    </div>

                    <nav className="nav flex-column sidebar-nav">
                        <Link to="/assignee-dashboard" className="nav-link active">
                            <span className="me-2">📁</span> Assignee Dashboard
                        </Link>
                    </nav>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                <header className="dashboard-header d-flex align-items-center justify-content-end">
                    <div className="header-title-bar">
                        <span>Issue Tracking System</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-warning" role="status"></div>
                            <p className="mt-2 text-muted">Loading issue...</p>
                        </div>
                    ) : !issue ? (
                        <div className="alert alert-danger">Issue not found.</div>
                    ) : (
                        <div className="detail-card bg-white p-4 rounded shadow-sm">
                            {/* Breadcrumb */}
                            <div className="breadcrumb-nav small text-muted mb-3">
                                <Link to="/assignee-dashboard" className="text-decoration-none text-muted">
                                    Issue Dashboard
                                </Link>
                                <span className="mx-2">/</span>
                                <span className="text-dark fw-semibold">Issue Details</span>
                            </div>

                            {successMsg && (
                                <div className="alert alert-success py-2 small mb-3">
                                    {successMsg}
                                </div>
                            )}
                            {errorMsg && (
                                <div className="alert alert-danger py-2 small mb-3">
                                    {errorMsg}
                                </div>
                            )}

                            {/* Issue Title */}
                            <h3 className="issue-detail-title text-warning fw-bold mb-3">
                                {issue.summary}
                            </h3>

                            {/* Description and Status Dropdown */}
                            <div className="row align-items-start mb-4">
                                <div className="col-md-8">
                                    <h6 className="fw-semibold text-muted mb-1">Description :</h6>
                                    <p className="text-secondary small">
                                        {issue.description || 'No description available for this issue.'}
                                    </p>
                                </div>

                                <div className="col-md-4">
                                    <select
                                        className="form-select status-change-select"
                                        value={selectedStatus}
                                        onChange={handleStatusChange}
                                    >
                                        <option value="TO_DO">TO_DO</option>
                                        <option value="DEVELOPMENT">DEVELOPMENT</option>
                                        <option value="TESTING">TESTING</option>
                                        <option value="COMPLETED">COMPLETED</option>
                                    </select>
                                </div>
                            </div>

                            <hr className="my-3 text-muted" />

                            {/* Details Row */}
                            <div className="row mb-4">
                                <div className="col-md-6">
                                    <h6 className="fw-bold mb-3 text-dark">Details</h6>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Type:</span>
                                        <span className="fw-bold">{issue.type}</span>
                                    </div>
                                    <div className="mb-2 small d-flex align-items-center">
                                        <span className="text-muted fw-semibold me-2">Tags:</span>
                                        <div>{renderTags(issue.tags)}</div>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Story Points:</span>
                                        <span className="fw-bold">{issue.storyPoint}</span>
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Sprint:</span>
                                        <span className="fw-bold">{issue.sprint || '1'}</span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Priority:</span>
                                        <span className="fw-bold">{issue.priority}</span>
                                    </div>
                                </div>
                            </div>

                            {/* Save Updates Button */}
                            <div className="text-center pt-3">
                                <button
                                    type="button"
                                    className="btn btn-warning px-4 py-2 fw-semibold"
                                    disabled={!isSaveEnabled || saving}
                                    onClick={handleSaveUpdates}
                                >
                                    {saving ? 'Saving...' : 'Save Updates'}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
}

export default AssigneeIssueDetail;
