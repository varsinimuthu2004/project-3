import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { createProject, getProjectsByOwner } from "../services/projectService";
import { getAllUsers } from "../services/userService";
import { getIssuesByOwnerId } from "../services/issueService";

function CreateProjectForm() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [projectName, setProjectName] = useState('');
    const [projectOwner, setProjectOwner] = useState(user?.userId || '');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const [touched, setTouched] = useState({});
    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState('');
    const [loading, setLoading] = useState(false);

    const [ownerList, setOwnerList] = useState([]);
    const [totalProjectsCount, setTotalProjectsCount] = useState(0);
    const [totalIssuesCount, setTotalIssuesCount] = useState(0);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const fetchMeta = async () => {
            try {
                const users = await getAllUsers();
                if (Array.isArray(users)) {
                    // Filter project owners
                    const owners = users.filter(u => u.role === 'PROJECT_OWNER');
                    setOwnerList(owners.length > 0 ? owners : users);
                }

                const prjs = await getProjectsByOwner(user.userId);
                setTotalProjectsCount(prjs?.length || 0);

                const issues = await getIssuesByOwnerId(user.userId);
                setTotalIssuesCount(issues?.length || 0);
            } catch {
                // Ignore silent fetch failures
            }
        };

        fetchMeta();
    }, [user]);

    const validateField = (field, value) => {
        switch (field) {
            case 'projectName':
                if (!value || !value.trim()) return 'Project Name is required.';
                if (value.trim().length > 150) return 'Project Name cannot exceed 150 characters.';
                if (!/^[a-zA-Z0-9\s\-/.|]+$/.test(value.trim())) {
                    return 'Special characters not allowed except {-, /, |, .}';
                }
                break;
            case 'projectOwner':
                if (!value) return 'Project Owner is required.';
                break;
            case 'startDate':
                if (!value) return 'Project Start Date is required.';
                break;
            case 'endDate':
                if (!value) return 'Project End Date is required.';
                if (startDate && new Date(value) < new Date(startDate)) {
                    return 'End date should not be lesser than start date.';
                }
                break;
            default:
                return '';
        }
        return '';
    };

    const handleBlur = (field) => {
        setTouched(prev => ({ ...prev, [field]: true }));
        let val = '';
        if (field === 'projectName') val = projectName;
        if (field === 'projectOwner') val = projectOwner;
        if (field === 'startDate') val = startDate;
        if (field === 'endDate') val = endDate;

        const err = validateField(field, val);
        setErrors(prev => ({ ...prev, [field]: err }));
    };

    const isFormValid = () => {
        return (
            projectName.trim() !== '' &&
            projectName.trim().length <= 150 &&
            /^[a-zA-Z0-9\s\-/.|]+$/.test(projectName.trim()) &&
            projectOwner !== '' &&
            startDate !== '' &&
            endDate !== '' &&
            new Date(endDate) >= new Date(startDate)
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');

        const formErrors = {
            projectName: validateField('projectName', projectName),
            projectOwner: validateField('projectOwner', projectOwner),
            startDate: validateField('startDate', startDate),
            endDate: validateField('endDate', endDate)
        };
        setErrors(formErrors);
        setTouched({ projectName: true, projectOwner: true, startDate: true, endDate: true });

        if (Object.values(formErrors).some(Boolean)) {
            return;
        }

        try {
            setLoading(true);
            const projectPayload = {
                projectName: projectName.trim(),
                projectOwner: Number(projectOwner),
                startDate: startDate,
                endDate: endDate
            };

            await createProject(projectPayload);
            navigate('/dashboard');
        } catch (err) {
            setServerError(err.message || 'Failed to create project.');
        } finally {
            setLoading(false);
        }
    };

    const handleReset = () => {
        setProjectName('');
        setProjectOwner(user?.userId || '');
        setStartDate('');
        setEndDate('');
        setErrors({});
        setTouched({});
        setServerError('');
    };

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Jack Finn"}</h6>
                        <small className="text-muted">{user?.emailId || "jack@xyz.com"}</small>
                    </div>

                    <div className="stats-box d-flex justify-content-around text-center py-2 mb-4">
                        <div>
                            <div className="stat-number fw-bold">{totalProjectsCount}</div>
                            <div className="stat-label small">Projects Created</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div>
                            <div className="stat-number fw-bold">{totalIssuesCount}</div>
                            <div className="stat-label small">Issues Created</div>
                        </div>
                    </div>

                    <nav className="nav flex-column sidebar-nav">
                        <Link to="/dashboard" className="nav-link">
                            <span className="me-2">📁</span> Project Dashboard
                        </Link>
                        <Link to="/create-project" className="nav-link active">
                            <span className="me-2">+</span> Create Project
                        </Link>
                        <Link to="/create-issue" className="nav-link">
                            <span className="me-2">+</span> Create Issue
                        </Link>
                    </nav>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                <header className="dashboard-header d-flex align-items-center justify-content-end">
                    <div className="header-title-bar">
                        <span>Issue Tracking System</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    <div className="form-card bg-white p-4 rounded shadow-sm">
                        <h5 className="form-card-title mb-4">Create Project</h5>

                        {serverError && (
                            <div className="alert alert-danger py-2 small mb-3">
                                {serverError}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            <div className="row mb-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Project Name</label>
                                    <input
                                        type="text"
                                        className={`form-control ${touched.projectName && errors.projectName ? 'is-invalid' : ''}`}
                                        placeholder="Enter project name"
                                        value={projectName}
                                        onChange={(e) => setProjectName(e.target.value)}
                                        onBlur={() => handleBlur('projectName')}
                                    />
                                    {touched.projectName && errors.projectName && (
                                        <div className="invalid-feedback small">{errors.projectName}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Project Owner</label>
                                    <select
                                        className={`form-select ${touched.projectOwner && errors.projectOwner ? 'is-invalid' : ''}`}
                                        value={projectOwner}
                                        onChange={(e) => setProjectOwner(e.target.value)}
                                        onBlur={() => handleBlur('projectOwner')}
                                    >
                                        <option value="">Select Project Owner</option>
                                        {ownerList.map(o => (
                                            <option key={o.userId} value={o.userId}>
                                                {o.name}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.projectOwner && errors.projectOwner && (
                                        <div className="invalid-feedback small">{errors.projectOwner}</div>
                                    )}
                                </div>
                            </div>

                            <div className="row mb-4">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Project Start Date</label>
                                    <input
                                        type="date"
                                        className={`form-control ${touched.startDate && errors.startDate ? 'is-invalid' : ''}`}
                                        value={startDate}
                                        onChange={(e) => setStartDate(e.target.value)}
                                        onBlur={() => handleBlur('startDate')}
                                    />
                                    {touched.startDate && errors.startDate && (
                                        <div className="invalid-feedback small">{errors.startDate}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Project End Date</label>
                                    <input
                                        type="date"
                                        className={`form-control ${touched.endDate && errors.endDate ? 'is-invalid' : ''}`}
                                        value={endDate}
                                        onChange={(e) => setEndDate(e.target.value)}
                                        onBlur={() => handleBlur('endDate')}
                                    />
                                    {touched.endDate && errors.endDate && (
                                        <div className="invalid-feedback small">{errors.endDate}</div>
                                    )}
                                </div>
                            </div>

                            <div className="d-flex justify-content-end gap-2">
                                <button
                                    type="submit"
                                    className="btn btn-warning px-4 fw-semibold"
                                    disabled={!isFormValid() || loading}
                                >
                                    {loading ? 'CREATING...' : 'CREATE'}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary px-4 fw-semibold"
                                    onClick={handleReset}
                                >
                                    RESET
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    );
}

export default CreateProjectForm;
