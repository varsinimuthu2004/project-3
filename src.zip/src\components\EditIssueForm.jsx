import React, { useContext, useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssueById, updateIssue, getIssuesByOwnerId } from "../services/issueService";
import { getProjectsByOwner, getAllProjects } from "../services/projectService";
import { getAllUsers } from "../services/userService";

function EditIssueForm() {
    const { id } = useParams();
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [initialData, setInitialData] = useState(null);
    const [form, setForm] = useState({
        summary: '',
        type: '',
        project: '',
        priority: '',
        description: '',
        assignee: '',
        tags: '',
        sprint: '',
        storyPoint: '',
        status: ''
    });

    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [serverError, setServerError] = useState('');
    const [loading, setLoading] = useState(false);

    const [projectList, setProjectList] = useState([]);
    const [assigneeList, setAssigneeList] = useState([]);
    const [totalProjectsCount, setTotalProjectsCount] = useState(0);
    const [totalIssuesCount, setTotalIssuesCount] = useState(0);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const loadData = async () => {
            try {
                // Fetch projects
                let prjs = await getProjectsByOwner(user.userId);
                if (!Array.isArray(prjs) || prjs.length === 0) {
                    prjs = await getAllProjects();
                }
                setProjectList(Array.isArray(prjs) ? prjs : []);
                setTotalProjectsCount(prjs?.length || 0);

                // Fetch assignees
                const users = await getAllUsers();
                if (Array.isArray(users)) {
                    const assignees = users.filter(u => u.role === 'ASSIGNEE');
                    setAssigneeList(assignees.length > 0 ? assignees : users);
                }

                // Stats
                const issues = await getIssuesByOwnerId(user.userId);
                setTotalIssuesCount(issues?.length || 0);

                // Fetch issue by ID
                const issueData = await getIssueById(id);
                if (issueData) {
                    const mapped = {
                        summary: issueData.summary || '',
                        type: issueData.type || 'TASK',
                        project: issueData.project || '',
                        priority: issueData.priority || 'MEDIUM',
                        description: issueData.description || '',
                        assignee: issueData.assignee || '',
                        tags: issueData.tags || '',
                        sprint: issueData.sprint || '1',
                        storyPoint: issueData.storyPoint !== undefined ? String(issueData.storyPoint) : '',
                        status: issueData.status || 'TO_DO'
                    };
                    setForm(mapped);
                    setInitialData(mapped);
                }
            } catch (err) {
                console.error("Error loading issue for edit:", err);
            }
        };

        loadData();
    }, [id, user]);

    const validateField = (name, value) => {
        switch (name) {
            case 'summary':
                if (!value || !value.trim()) return 'Summary is required.';
                if (value.trim().length < 5 || value.trim().length > 150) {
                    return 'Summary must be between 5 and 150 characters.';
                }
                break;
            case 'type':
                if (!value) return 'Type is required.';
                break;
            case 'project':
                if (!value) return 'Project is required.';
                break;
            case 'priority':
                if (!value) return 'Priority is required.';
                break;
            case 'description':
                if (value && value.length > 500) {
                    return 'Description cannot exceed 500 characters.';
                }
                break;
            case 'assignee':
                if (!value) return 'Assignee is required.';
                break;
            case 'sprint':
                if (!value || !/^[1-9][0-9]*$/.test(String(value))) {
                    return 'Sprint must be a positive integer.';
                }
                break;
            case 'storyPoint':
                if (value === '' || isNaN(value) || Number(value) < 1) {
                    return 'Story Point must be a positive integer.';
                }
                break;
            case 'status':
                if (!value) return 'Status is required.';
                break;
            default:
                return '';
        }
        return '';
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: value }));

        if (touched[name]) {
            setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
        }
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
    };

    const isFormValid = () => {
        return (
            form.summary.trim().length >= 5 &&
            form.type !== '' &&
            form.project !== '' &&
            form.priority !== '' &&
            form.assignee !== '' &&
            form.status !== '' &&
            /^[1-9][0-9]*$/.test(String(form.sprint)) &&
            Number(form.storyPoint) >= 1 &&
            (!form.description || form.description.length <= 500)
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');

        const formErrors = {};
        Object.keys(form).forEach(key => {
            const err = validateField(key, form[key]);
            if (err) formErrors[key] = err;
        });

        setErrors(formErrors);
        const touchedAll = {};
        Object.keys(form).forEach(k => { touchedAll[k] = true; });
        setTouched(touchedAll);

        if (Object.keys(formErrors).length > 0) {
            return;
        }

        try {
            setLoading(true);
            const payload = {
                summary: form.summary.trim(),
                description: form.description ? form.description.trim() : '',
                project: Number(form.project),
                assignee: Number(form.assignee),
                createdBy: user.userId,
                type: form.type,
                priority: form.priority,
                status: form.status,
                sprint: String(form.sprint),
                storyPoint: Number(form.storyPoint),
                tags: form.tags ? form.tags.trim() : ''
            };

            await updateIssue(id, payload);
            navigate(`/issue-details/${id}`);
        } catch (err) {
            setServerError(err.message || 'Failed to update issue.');
        } finally {
            setLoading(false);
        }
    };

    const handleReset = () => {
        if (initialData) {
            setForm(initialData);
        }
        setErrors({});
        setTouched({});
        setServerError('');
    };

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Jack Finn"}</h6>
                        <small className="text-muted">{user?.emailId || "jack@xyz.com"}</small>
                    </div>

                    <div className="stats-box d-flex justify-content-around text-center py-2 mb-4">
                        <div>
                            <div className="stat-number fw-bold">{totalProjectsCount}</div>
                            <div className="stat-label small">Projects Created</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div>
                            <div className="stat-number fw-bold">{totalIssuesCount}</div>
                            <div className="stat-label small">Issues Created</div>
                        </div>
                    </div>

                    <nav className="nav flex-column sidebar-nav">
                        <Link to="/dashboard" className="nav-link active">
                            <span className="me-2">📁</span> Project Dashboard
                        </Link>
                        <Link to="/create-project" className="nav-link">
                            <span className="me-2">+</span> Create Project
                        </Link>
                        <Link to="/create-issue" className="nav-link">
                            <span className="me-2">+</span> Create Issue
                        </Link>
                    </nav>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                <header className="dashboard-header d-flex align-items-center justify-content-end">
                    <div className="header-title-bar">
                        <span>Deloitte Engineering</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    <div className="form-card bg-white p-4 rounded shadow-sm">
                        <h5 className="form-card-title mb-4">Edit Issue</h5>

                        {serverError && (
                            <div className="alert alert-danger py-2 small mb-3">
                                {serverError}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            {/* Summary & Type */}
                            <div className="row mb-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Summary</label>
                                    <input
                                        type="text"
                                        className={`form-control ${touched.summary && errors.summary ? 'is-invalid' : ''}`}
                                        name="summary"
                                        value={form.summary}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {touched.summary && errors.summary && (
                                        <div className="invalid-feedback small">{errors.summary}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Type</label>
                                    <select
                                        className={`form-select ${touched.type && errors.type ? 'is-invalid' : ''}`}
                                        name="type"
                                        value={form.type}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    >
                                        <option value="">Select type</option>
                                        <option value="BUG">BUG</option>
                                        <option value="TASK">TASK</option>
                                        <option value="STORY">STORY</option>
                                    </select>
                                    {touched.type && errors.type && (
                                        <div className="invalid-feedback small">{errors.type}</div>
                                    )}
                                </div>
                            </div>

                            {/* Project & Priority */}
                            <div className="row mb-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Project</label>
                                    <select
                                        className={`form-select ${touched.project && errors.project ? 'is-invalid' : ''}`}
                                        name="project"
                                        value={form.project}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    >
                                        <option value="">Select project</option>
                                        {projectList.map(p => (
                                            <option key={p.id} value={p.id}>
                                                {p.projectName}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.project && errors.project && (
                                        <div className="invalid-feedback small">{errors.project}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Priority</label>
                                    <select
                                        className={`form-select ${touched.priority && errors.priority ? 'is-invalid' : ''}`}
                                        name="priority"
                                        value={form.priority}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    >
                                        <option value="">Select priority</option>
                                        <option value="LOW">LOW</option>
                                        <option value="MEDIUM">MEDIUM</option>
                                        <option value="HIGH">HIGH</option>
                                    </select>
                                    {touched.priority && errors.priority && (
                                        <div className="invalid-feedback small">{errors.priority}</div>
                                    )}
                                </div>
                            </div>

                            {/* Description */}
                            <div className="mb-3">
                                <label className="form-label small text-muted mb-1">Description</label>
                                <textarea
                                    className={`form-control ${touched.description && errors.description ? 'is-invalid' : ''}`}
                                    name="description"
                                    rows="2"
                                    value={form.description}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.description && errors.description && (
                                    <div className="invalid-feedback small">{errors.description}</div>
                                )}
                            </div>

                            {/* Assignee & Tags */}
                            <div className="row mb-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Assignee</label>
                                    <select
                                        className={`form-select ${touched.assignee && errors.assignee ? 'is-invalid' : ''}`}
                                        name="assignee"
                                        value={form.assignee}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    >
                                        <option value="">Select assignee</option>
                                        {assigneeList.map(a => (
                                            <option key={a.userId} value={a.userId}>
                                                {a.name}
                                            </option>
                                        ))}
                                    </select>
                                    {touched.assignee && errors.assignee && (
                                        <div className="invalid-feedback small">{errors.assignee}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Tags</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        name="tags"
                                        value={form.tags}
                                        onChange={handleChange}
                                    />
                                </div>
                            </div>

                            {/* Sprint & Story Point */}
                            <div className="row mb-3">
                                <div className="col-md-6 mb-3 mb-md-0">
                                    <label className="form-label small text-muted mb-1">Sprint</label>
                                    <input
                                        type="number"
                                        className={`form-control ${touched.sprint && errors.sprint ? 'is-invalid' : ''}`}
                                        name="sprint"
                                        value={form.sprint}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {touched.sprint && errors.sprint && (
                                        <div className="invalid-feedback small">{errors.sprint}</div>
                                    )}
                                </div>

                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Story Point</label>
                                    <input
                                        type="number"
                                        className={`form-control ${touched.storyPoint && errors.storyPoint ? 'is-invalid' : ''}`}
                                        name="storyPoint"
                                        value={form.storyPoint}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {touched.storyPoint && errors.storyPoint && (
                                        <div className="invalid-feedback small">{errors.storyPoint}</div>
                                    )}
                                </div>
                            </div>

                            {/* Status */}
                            <div className="row mb-4">
                                <div className="col-md-6">
                                    <label className="form-label small text-muted mb-1">Status</label>
                                    <select
                                        className={`form-select ${touched.status && errors.status ? 'is-invalid' : ''}`}
                                        name="status"
                                        value={form.status}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    >
                                        <option value="TO_DO">TO_DO</option>
                                        <option value="DEVELOPMENT">DEVELOPMENT</option>
                                        <option value="TESTING">TESTING</option>
                                        <option value="COMPLETED">COMPLETED</option>
                                    </select>
                                    {touched.status && errors.status && (
                                        <div className="invalid-feedback small">{errors.status}</div>
                                    )}
                                </div>
                            </div>

                            {/* Buttons */}
                            <div className="d-flex justify-content-end gap-2">
                                <button
                                    type="submit"
                                    className="btn btn-warning px-4 fw-semibold"
                                    disabled={!isFormValid() || loading}
                                >
                                    {loading ? 'SAVING...' : 'EDIT'}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-outline-secondary px-4 fw-semibold"
                                    onClick={handleReset}
                                >
                                    RESET
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    );
}

export default EditIssueForm;
