import React, { useContext, useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssueById, getIssuesByOwnerId } from "../services/issueService";
import { getAllUsers } from "../services/userService";
import { getProjectsByOwner } from "../services/projectService";

function IssueDetail() {
    const { id } = useParams();
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [issue, setIssue] = useState(null);
    const [assigneeUser, setAssigneeUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [totalProjectsCount, setTotalProjectsCount] = useState(0);
    const [totalIssuesCount, setTotalIssuesCount] = useState(0);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        try {
            const parts = dateStr.split('-');
            if (parts.length === 3) {
                return `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
            return dateStr;
        } catch {
            return dateStr;
        }
    };

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const fetchDetails = async () => {
            try {
                setLoading(true);
                const issueData = await getIssueById(id);
                setIssue(issueData);

                // Fetch users to resolve Assignee name
                const users = await getAllUsers();
                if (Array.isArray(users) && issueData?.assignee) {
                    const found = users.find(u => String(u.userId) === String(issueData.assignee));
                    setAssigneeUser(found);
                }

                // Stats
                const prjs = await getProjectsByOwner(user.userId);
                setTotalProjectsCount(prjs?.length || 0);
                const issues = await getIssuesByOwnerId(user.userId);
                setTotalIssuesCount(issues?.length || 0);
            } catch (err) {
                console.error("Error loading issue details:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchDetails();
    }, [id, user]);

    // Parse tags into array
    const renderTags = (tagsStr) => {
        if (!tagsStr) return null;
        const tagList = tagsStr.split(/[\s,]+/).filter(Boolean);
        return tagList.map((tag, idx) => (
            <span key={idx} className="badge bg-success me-1 text-white fw-normal">
                {tag.startsWith('#') ? tag : `#${tag}`}
            </span>
        ));
    };

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Jack Finn"}</h6>
                        <small className="text-muted">{user?.emailId || "jack@xyz.com"}</small>
                    </div>

                    <div className="stats-box d-flex justify-content-around text-center py-2 mb-4">
                        <div>
                            <div className="stat-number fw-bold">{totalProjectsCount}</div>
                            <div className="stat-label small">Projects Created</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div>
                            <div className="stat-number fw-bold">{totalIssuesCount}</div>
                            <div className="stat-label small">Issues Created</div>
                        </div>
                    </div>

                    <nav className="nav flex-column sidebar-nav">
                        <Link to="/dashboard" className="nav-link active">
                            <span className="me-2">📁</span> Project Dashboard
                        </Link>
                        <Link to="/create-project" className="nav-link">
                            <span className="me-2">+</span> Create Project
                        </Link>
                        <Link to="/create-issue" className="nav-link">
                            <span className="me-2">+</span> Create Issue
                        </Link>
                    </nav>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                <header className="dashboard-header d-flex align-items-center justify-content-end">
                    <div className="header-title-bar">
                        <span>Deloitte Engineering</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-warning" role="status"></div>
                            <p className="mt-2 text-muted">Loading issue details...</p>
                        </div>
                    ) : !issue ? (
                        <div className="alert alert-danger">Issue not found.</div>
                    ) : (
                        <div className="detail-card bg-white p-4 rounded shadow-sm">
                            {/* Breadcrumb */}
                            <div className="breadcrumb-nav small text-muted mb-3">
                                <Link to="/dashboard" className="text-decoration-none text-muted">
                                    Project Board
                                </Link>
                                <span className="mx-2">/</span>
                                <span className="text-dark fw-semibold">Issue Details</span>
                            </div>

                            {/* Title & Edit Button */}
                            <div className="d-flex justify-content-between align-items-start mb-3">
                                <h3 className="issue-detail-title text-warning fw-bold mb-0">
                                    {issue.summary}
                                </h3>
                                <Link
                                    to={`/edit-issue/${issue.id}`}
                                    className="btn btn-dark btn-sm px-3 fw-semibold"
                                >
                                    Edit Issue
                                </Link>
                            </div>

                            {/* Description */}
                            <div className="mb-4">
                                <h6 className="fw-semibold text-muted mb-1">Description :</h6>
                                <p className="text-secondary small">
                                    {issue.description || 'No description available for this issue.'}
                                </p>
                            </div>

                            <hr className="my-3 text-muted" />

                            {/* Details Grid */}
                            <div className="row">
                                <div className="col-md-6">
                                    <h6 className="fw-bold mb-3 text-dark">Details</h6>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Type:</span>
                                        <span className="fw-bold">{issue.type}</span>
                                    </div>
                                    <div className="mb-2 small d-flex align-items-center">
                                        <span className="text-muted fw-semibold me-2">Tags:</span>
                                        <div>{renderTags(issue.tags)}</div>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Story Points:</span>
                                        <span className="fw-bold">{issue.storyPoint}</span>
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Status:</span>
                                        <span className="fw-bold text-success">{issue.status}</span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Assignee:</span>
                                        <span className="fw-semibold text-primary">
                                            {assigneeUser?.name || `Assignee #${issue.assignee}`}
                                        </span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Sprint:</span>
                                        <span className="fw-bold">{issue.sprint || '1'}</span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Priority:</span>
                                        <span className="fw-bold">{issue.priority}</span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Created On:</span>
                                        <span>{formatDate(issue.createdOn)}</span>
                                    </div>
                                    <div className="mb-2 small">
                                        <span className="text-muted fw-semibold me-2">Last Updated:</span>
                                        <span>{formatDate(issue.lastUpdated)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
}

export default IssueDetail;
