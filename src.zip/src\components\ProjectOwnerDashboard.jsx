import React, { useContext, useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner, getAllProjects, getIssuesByProjectId } from "../services/projectService";
import { getAllUsers } from "../services/userService";
import { getIssuesByOwnerId } from "../services/issueService";

function ProjectOwnerDashboard() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState(null);
    const [issues, setIssues] = useState([]);
    const [usersMap, setUsersMap] = useState({});
    const [assigneeList, setAssigneeList] = useState([]);

    const [searchText, setSearchText] = useState('');
    const [filterAssignee, setFilterAssignee] = useState('All');
    const [filterPriority, setFilterPriority] = useState('All');

    const [totalProjectsCount, setTotalProjectsCount] = useState(0);
    const [totalIssuesCount, setTotalIssuesCount] = useState(0);
    const [loading, setLoading] = useState(true);

    const handleLogout = () => {
        ctxLogout();
        navigate('/login');
    };

    useEffect(() => {
        const loadInitialData = async () => {
            if (!user) {
                navigate('/login');
                return;
            }
            try {
                setLoading(true);

                // Fetch all users to map assignee names & avatars
                const allUsers = await getAllUsers();
                const uMap = {};
                if (Array.isArray(allUsers)) {
                    allUsers.forEach(u => {
                        uMap[u.userId] = u;
                    });
                    setUsersMap(uMap);
                    setAssigneeList(allUsers.filter(u => u.role === 'ASSIGNEE'));
                }

                // Fetch projects owned by this user
                let userProjects = await getProjectsByOwner(user.userId);
                if (!Array.isArray(userProjects) || userProjects.length === 0) {
                    // Fallback to fetch all and filter if needed
                    const allPrjs = await getAllProjects();
                    if (Array.isArray(allPrjs)) {
                        userProjects = allPrjs.filter(p => String(p.projectOwner) === String(user.userId));
                    }
                }

                setProjects(userProjects || []);
                setTotalProjectsCount(userProjects?.length || 0);

                // Fetch all issues created by owner for stats counter
                try {
                    const ownerIssues = await getIssuesByOwnerId(user.userId);
                    setTotalIssuesCount(ownerIssues?.length || 0);
                } catch {
                    setTotalIssuesCount(0);
                }

                if (userProjects && userProjects.length > 0) {
                    // Default to first project
                    const firstProject = userProjects[0];
                    setSelectedProject(firstProject);
                    await loadProjectIssues(firstProject.id);
                }
            } catch (err) {
                console.error("Dashboard data load error:", err);
            } finally {
                setLoading(false);
            }
        };

        loadInitialData();
    }, [user]);

    const loadProjectIssues = async (projectId) => {
        try {
            const projectIssues = await getIssuesByProjectId(projectId);
            setIssues(Array.isArray(projectIssues) ? projectIssues : []);
        } catch (err) {
            console.error("Error loading project issues:", err);
            setIssues([]);
        }
    };

    const handleProjectChange = async (e) => {
        const projId = e.target.value;
        const found = projects.find(p => String(p.id) === String(projId));
        if (found) {
            setSelectedProject(found);
            await loadProjectIssues(found.id);
        }
    };

    // Format date string from YYYY-MM-DD to dd-mm-yyyy
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        try {
            const parts = dateStr.split('-');
            if (parts.length === 3) {
                return `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
            const d = new Date(dateStr);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            return `${day}-${month}-${year}`;
        } catch {
            return dateStr;
        }
    };

    // Filter issues based on Regex search and dropdown filters
    const filteredIssues = useMemo(() => {
        return issues.filter(issue => {
            // Regex search on summary or description
            if (searchText.trim()) {
                try {
                    const regex = new RegExp(searchText.trim(), 'i');
                    const matchSummary = issue.summary && regex.test(issue.summary);
                    const matchDesc = issue.description && regex.test(issue.description);
                    if (!matchSummary && !matchDesc) return false;
                } catch {
                    const term = searchText.toLowerCase();
                    const inSummary = issue.summary?.toLowerCase().includes(term);
                    const inDesc = issue.description?.toLowerCase().includes(term);
                    if (!inSummary && !inDesc) return false;
                }
            }

            // Assignee filter
            if (filterAssignee !== 'All') {
                const assigneeObj = usersMap[issue.assignee];
                const assigneeName = assigneeObj?.name || '';
                if (assigneeName !== filterAssignee && String(issue.assignee) !== filterAssignee) {
                    return false;
                }
            }

            // Priority filter
            if (filterPriority !== 'All') {
                if (issue.priority !== filterPriority) return false;
            }

            return true;
        });
    }, [issues, searchText, filterAssignee, filterPriority, usersMap]);

    // Group issues by category status
    const todoIssues = filteredIssues.filter(i => i.status === 'TO_DO');
    const devIssues = filteredIssues.filter(i => i.status === 'DEVELOPMENT');
    const testIssues = filteredIssues.filter(i => i.status === 'TESTING');
    const completedIssues = filteredIssues.filter(i => i.status === 'COMPLETED' || i.status === 'DONE');

    const getPriorityBadgeClass = (priority) => {
        switch (priority) {
            case 'HIGH':
                return 'badge-priority-high';
            case 'MEDIUM':
                return 'badge-priority-medium';
            case 'LOW':
                return 'badge-priority-low';
            default:
                return 'badge-priority-medium';
        }
    };

    return (
        <div className="dashboard-container d-flex">
            {/* Sidebar */}
            <aside className="sidebar-container text-white d-flex flex-column justify-content-between p-3">
                <div>
                    <div className="text-center profile-section mb-4">
                        <img
                            src={user?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn')}
                            alt={user?.name || "User Avatar"}
                            className="profile-avatar mb-2"
                            onError={(e) => {
                                e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user?.name || 'Jack Finn');
                            }}
                        />
                        <h6 className="mb-0 fw-semibold">{user?.name || "Jack Finn"}</h6>
                        <small className="text-muted">{user?.emailId || "jack@xyz.com"}</small>
                    </div>

                    <div className="stats-box d-flex justify-content-around text-center py-2 mb-4">
                        <div>
                            <div className="stat-number fw-bold">{totalProjectsCount}</div>
                            <div className="stat-label small">Projects Created</div>
                        </div>
                        <div className="stat-divider"></div>
                        <div>
                            <div className="stat-number fw-bold">{totalIssuesCount}</div>
                            <div className="stat-label small">Issues Created</div>
                        </div>
                    </div>

                    <nav className="nav flex-column sidebar-nav">
                        <Link to="/dashboard" className="nav-link active">
                            <span className="me-2">📁</span> Project Dashboard
                        </Link>
                        <Link to="/create-project" className="nav-link">
                            <span className="me-2">+</span> Create Project
                        </Link>
                        <Link to="/create-issue" className="nav-link">
                            <span className="me-2">+</span> Create Issue
                        </Link>
                    </nav>
                </div>

                <div>
                    <button onClick={handleLogout} className="btn-logout d-flex align-items-center">
                        <span className="me-2">↪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="main-content-wrapper flex-grow-1">
                {/* Header */}
                <header className="dashboard-header d-flex align-items-center justify-content-between">
                    <div className="search-bar-container">
                        <input
                            type="text"
                            className="form-control search-input"
                            placeholder="Search issue by summary or description"
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                        />
                    </div>
                    <div className="header-title-bar">
                        <span>Issue Tracking System</span>
                    </div>
                </header>

                <div className="p-4 content-body">
                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-warning" role="status"></div>
                            <p className="mt-2 text-muted">Loading dashboard...</p>
                        </div>
                    ) : projects.length === 0 ? (
                        /* No Projects Screen */
                        <div className="no-projects-view text-center py-5">
                            <h4 className="fw-normal text-muted mb-3">No Projects Available !</h4>
                            <Link to="/create-project" className="btn btn-link text-warning text-decoration-none fw-semibold">
                                Create Project
                            </Link>
                        </div>
                    ) : (
                        /* Project Dashboard Content */
                        <>
                            <h6 className="dashboard-subheading mb-3">PROJECT DASHBOARD</h6>

                            <div className="project-meta-card mb-4 p-3 bg-white rounded shadow-sm">
                                <div className="row align-items-center">
                                    <div className="col-md-6 mb-2 mb-md-0">
                                        <label className="form-label small text-muted mb-1">Project Name</label>
                                        <select
                                            className="form-select project-select"
                                            value={selectedProject?.id || ''}
                                            onChange={handleProjectChange}
                                        >
                                            {projects.map(p => (
                                                <option key={p.id} value={p.id}>
                                                    {p.projectName}
                                                </option>
                                            ))}
                                        </select>
                                        {selectedProject && (
                                            <div className="date-range-text small text-muted mt-2">
                                                Start Date: {formatDate(selectedProject.startDate)} | End Date: {formatDate(selectedProject.endDate)}
                                            </div>
                                        )}
                                    </div>
                                    <div className="col-md-6 text-md-end">
                                        <span className="small text-muted me-2">Project Owner Name:</span>
                                        <span className="fw-semibold text-uppercase">{user?.name || "JACK FINN"}</span>
                                    </div>
                                </div>

                                <hr className="my-3 text-muted" />

                                <div className="row filters-row">
                                    <div className="col-md-6 mb-2 mb-md-0">
                                        <label className="form-label small text-muted mb-1">Filter by Assignee</label>
                                        <select
                                            className="form-select filter-select"
                                            value={filterAssignee}
                                            onChange={(e) => setFilterAssignee(e.target.value)}
                                        >
                                            <option value="All">All</option>
                                            {assigneeList.map(a => (
                                                <option key={a.userId} value={a.name}>
                                                    {a.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="col-md-6">
                                        <label className="form-label small text-muted mb-1">Filter by Priority</label>
                                        <select
                                            className="form-select filter-select"
                                            value={filterPriority}
                                            onChange={(e) => setFilterPriority(e.target.value)}
                                        >
                                            <option value="All">All</option>
                                            <option value="LOW">LOW</option>
                                            <option value="MEDIUM">MEDIUM</option>
                                            <option value="HIGH">HIGH</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            {/* Kanban Board */}
                            <div className="kanban-board-container row g-3">
                                {/* TO DO Column */}
                                <div className="col-md-3">
                                    <div className="kanban-column-card">
                                        <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                            <span className="column-title">📋 TO DO</span>
                                            <span className="badge badge-column-count badge-todo">{todoIssues.length}</span>
                                        </div>
                                        <div className="kanban-cards-wrapper p-2">
                                            {todoIssues.map(issue => (
                                                <IssueCard
                                                    key={issue.id}
                                                    issue={issue}
                                                    userObj={usersMap[issue.assignee]}
                                                    formatDate={formatDate}
                                                    getPriorityBadgeClass={getPriorityBadgeClass}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* DEVELOPMENT Column */}
                                <div className="col-md-3">
                                    <div className="kanban-column-card">
                                        <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                            <span className="column-title">&lt;/&gt; DEVELOPMENT</span>
                                            <span className="badge badge-column-count badge-dev">{devIssues.length}</span>
                                        </div>
                                        <div className="kanban-cards-wrapper p-2">
                                            {devIssues.map(issue => (
                                                <IssueCard
                                                    key={issue.id}
                                                    issue={issue}
                                                    userObj={usersMap[issue.assignee]}
                                                    formatDate={formatDate}
                                                    getPriorityBadgeClass={getPriorityBadgeClass}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* TESTING Column */}
                                <div className="col-md-3">
                                    <div className="kanban-column-card">
                                        <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                            <span className="column-title">🧪 TESTING</span>
                                            <span className="badge badge-column-count badge-testing">{testIssues.length}</span>
                                        </div>
                                        <div className="kanban-cards-wrapper p-2">
                                            {testIssues.map(issue => (
                                                <IssueCard
                                                    key={issue.id}
                                                    issue={issue}
                                                    userObj={usersMap[issue.assignee]}
                                                    formatDate={formatDate}
                                                    getPriorityBadgeClass={getPriorityBadgeClass}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* COMPLETED Column */}
                                <div className="col-md-3">
                                    <div className="kanban-column-card">
                                        <div className="kanban-column-header d-flex justify-content-between align-items-center">
                                            <span className="column-title">☑ COMPLETED</span>
                                            <span className="badge badge-column-count badge-completed">{completedIssues.length}</span>
                                        </div>
                                        <div className="kanban-cards-wrapper p-2">
                                            {completedIssues.map(issue => (
                                                <IssueCard
                                                    key={issue.id}
                                                    issue={issue}
                                                    userObj={usersMap[issue.assignee]}
                                                    formatDate={formatDate}
                                                    getPriorityBadgeClass={getPriorityBadgeClass}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </main>
        </div>
    );
}

function IssueCard({ issue, userObj, formatDate, getPriorityBadgeClass }) {
    const assigneeName = userObj?.name || 'Unassigned';
    const avatarUrl = userObj?.profileImage || "https://ui-avatars.com/api/?name=" + encodeURIComponent(assigneeName);

    return (
        <div className="issue-card bg-white p-3 rounded mb-2 shadow-sm">
            <div className="d-flex justify-content-between align-items-center mb-1">
                <span className="issue-id small text-muted fw-semibold">Id: {issue.id}</span>
                <span className="issue-date small text-muted">{formatDate(issue.createdOn)}</span>
            </div>
            <Link to={`/issue-details/${issue.id}`} className="issue-summary-link d-block mb-1 fw-bold text-dark text-decoration-none">
                {issue.summary}
            </Link>
            <p className="issue-desc-text small text-muted mb-3">
                {issue.description || 'No description provided.'}
            </p>
            <div className="d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center">
                    <img
                        src={avatarUrl}
                        alt={assigneeName}
                        className="assignee-avatar-sm me-2"
                        onError={(e) => {
                            e.target.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(assigneeName);
                        }}
                    />
                    <span className="small text-muted">{assigneeName}</span>
                </div>
                <span className={`badge ${getPriorityBadgeClass(issue.priority)}`}>
                    {issue.priority}
                </span>
            </div>
        </div>
    );
}

export default ProjectOwnerDashboard;
