import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { login } from "../services/userService";
import { AuthContext } from "../context/AuthContext";

function UserLoginForm() {
    const [form, setForm] = useState({
        emailId: '',
        password: '',
        role: ''
    });

    const [touched, setTouched] = useState({
        emailId: false,
        password: false,
        role: false
    });

    const [fieldErrors, setFieldErrors] = useState({});
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();
    const { ctxLogin } = useContext(AuthContext);

    const getFieldError = (name, value) => {
        switch (name) {
            case 'emailId':
                if (!value || !value.trim()) return 'Email address is required.';
                if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value.trim())) {
                    return 'Please enter a valid email address.';
                }
                break;
            case 'password':
                if (!value) return 'Password is required.';
                if (value.length < 6) return 'Password must be at least 6 characters.';
                break;
            case 'role':
                if (!value) return 'Role is required.';
                break;
            default:
                return '';
        }
        return '';
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        const updatedForm = { ...form, [name]: value };
        setForm(updatedForm);

        if (touched[name]) {
            setFieldErrors(prev => ({
                ...prev,
                [name]: getFieldError(name, value)
            }));
        }
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        setFieldErrors(prev => ({
            ...prev,
            [name]: getFieldError(name, value)
        }));
    };

    const isFormValid = () => {
        return (
            form.emailId.trim() !== '' &&
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(form.emailId.trim()) &&
            form.password.length >= 6 &&
            form.role !== ''
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        const errors = {
            emailId: getFieldError('emailId', form.emailId),
            password: getFieldError('password', form.password),
            role: getFieldError('role', form.role)
        };
        setFieldErrors(errors);
        setTouched({ emailId: true, password: true, role: true });

        if (errors.emailId || errors.password || errors.role) {
            return;
        }

        try {
            setLoading(true);
            const backendRole = form.role === 'Project Owner' ? 'PROJECT_OWNER' : 'ASSIGNEE';
            const result = await login(form.emailId.trim(), form.password, backendRole);

            if (result.success && result.user) {
                ctxLogin(result.user);
                if (result.user.role === 'PROJECT_OWNER') {
                    navigate('/dashboard');
                } else {
                    navigate('/assignee-dashboard');
                }
            } else {
                setError(result.error || 'Invalid credentials or role mismatch.');
            }
        } catch (err) {
            setError(err.message || 'An unexpected error occurred during login.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-screen-wrapper">
            <header className="top-branding-bar">
                <span className="brand-title">Issue Tracking System</span>
            </header>

            <div className="auth-card-container">
                <div className="card auth-card shadow-sm">
                    <div className="card-body p-4">
                        <h4 className="auth-heading text-center mb-4">Login</h4>

                        {error && (
                            <div className="alert alert-danger py-2 small" role="alert">
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Email address</label>
                                <input
                                    type="email"
                                    className={`form-control ${touched.emailId && fieldErrors.emailId ? 'is-invalid' : ''}`}
                                    placeholder="Enter email"
                                    name="emailId"
                                    value={form.emailId}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.emailId && fieldErrors.emailId && (
                                    <div className="invalid-feedback small">{fieldErrors.emailId}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Password</label>
                                <input
                                    type="password"
                                    className={`form-control ${touched.password && fieldErrors.password ? 'is-invalid' : ''}`}
                                    placeholder="Password"
                                    name="password"
                                    value={form.password}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.password && fieldErrors.password && (
                                    <div className="invalid-feedback small">{fieldErrors.password}</div>
                                )}
                            </div>

                            <div className="mb-4">
                                <label className="form-label text-muted small mb-1">Role:</label>
                                <select
                                    className={`form-select ${touched.role && fieldErrors.role ? 'is-invalid' : ''}`}
                                    name="role"
                                    value={form.role}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                >
                                    <option value="">Select your role</option>
                                    <option value="Project Owner">Project Owner</option>
                                    <option value="Assignee">Assignee</option>
                                </select>
                                {touched.role && fieldErrors.role && (
                                    <div className="invalid-feedback small">{fieldErrors.role}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <button
                                    type="submit"
                                    className="btn btn-warning btn-login-custom"
                                    disabled={!isFormValid() || loading}
                                >
                                    {loading ? 'Logging in...' : 'Login'}
                                </button>
                            </div>

                            <div className="text-center mt-3">
                                <span className="small text-muted">Don't have an account? </span>
                                <Link to="/signup" className="small text-decoration-none fw-semibold">
                                    Signup
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserLoginForm;
