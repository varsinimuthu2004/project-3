import React, { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import User from "../model/User";
import { registerUser } from "../services/userService";

function UserSignupForm() {
    // Uncontrolled component pattern using useRef as instructed in use-case
    const nameRef = useRef();
    const emailRef = useRef();
    const passwordRef = useRef();
    const profileImageRef = useRef();
    const roleRef = useRef();

    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [serverError, setServerError] = useState('');
    const [serverSuccess, setServerSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();

    const validateField = (name, value) => {
        switch (name) {
            case 'name':
                if (!value || !value.trim()) return 'Name is mandatory and cannot be left blank.';
                if (value.trim().length < 2) return 'Name must be at least 2 characters.';
                break;
            case 'email':
                if (!value || !value.trim()) return 'Email is required.';
                if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value.trim())) {
                    return 'Please enter a valid email address.';
                }
                break;
            case 'password':
                if (!value) return 'Password is required.';
                if (value.length < 6) return 'Password must be at least 6 characters long.';
                break;
            case 'profileImage':
                if (!value || !value.trim()) return 'Profile image URL is mandatory.';
                try {
                    const parsedUrl = new URL(value.trim());
                    if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
                        return 'Profile image URL must begin with http:// or https://';
                    }
                } catch {
                    return 'Please provide a valid image URL string format.';
                }
                break;
            case 'role':
                if (!value) return 'Role is required.';
                break;
            default:
                return '';
        }
        return '';
    };

    const handleBlur = (fieldName) => {
        let value = '';
        if (fieldName === 'name') value = nameRef.current?.value || '';
        if (fieldName === 'email') value = emailRef.current?.value || '';
        if (fieldName === 'password') value = passwordRef.current?.value || '';
        if (fieldName === 'profileImage') value = profileImageRef.current?.value || '';
        if (fieldName === 'role') value = roleRef.current?.value || '';

        setTouched(prev => ({ ...prev, [fieldName]: true }));
        const err = validateField(fieldName, value);
        setErrors(prev => ({ ...prev, [fieldName]: err }));
        return err;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setServerError('');
        setServerSuccess('');

        const nameVal = nameRef.current?.value || '';
        const emailVal = emailRef.current?.value || '';
        const passwordVal = passwordRef.current?.value || '';
        const profileImageVal = profileImageRef.current?.value || '';
        const roleVal = roleRef.current?.value || '';

        const validationErrors = {
            name: validateField('name', nameVal),
            email: validateField('email', emailVal),
            password: validateField('password', passwordVal),
            profileImage: validateField('profileImage', profileImageVal),
            role: validateField('role', roleVal)
        };

        setErrors(validationErrors);
        setTouched({ name: true, email: true, password: true, profileImage: true, role: true });

        const hasErrors = Object.values(validationErrors).some(err => Boolean(err));
        if (hasErrors) {
            return;
        }

        try {
            setLoading(true);
            const backendRole = roleVal === 'Project Owner' ? 'PROJECT_OWNER' : 'ASSIGNEE';
            const newUser = new User(
                null,
                nameVal.trim(),
                emailVal.trim(),
                backendRole,
                passwordVal,
                profileImageVal.trim()
            );

            await registerUser(newUser);
            setServerSuccess('User registered successfully! Redirecting to login...');
            setTimeout(() => {
                navigate('/login');
            }, 1500);
        } catch (err) {
            setServerError(err.message || 'Registration failed. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-screen-wrapper">
            <header className="top-branding-bar">
                <span className="brand-title">Issue Tracking System</span>
            </header>

            <div className="auth-card-container">
                <div className="card auth-card shadow-sm">
                    <div className="card-body p-4">
                        <h4 className="auth-heading text-center mb-4">Signup</h4>

                        {serverSuccess && (
                            <div className="alert alert-success py-2 small" role="alert">
                                {serverSuccess}
                            </div>
                        )}
                        {serverError && (
                            <div className="alert alert-danger py-2 small" role="alert">
                                {serverError}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} noValidate>
                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Name</label>
                                <input
                                    type="text"
                                    className={`form-control ${touched.name && errors.name ? 'is-invalid' : ''}`}
                                    placeholder="Enter name"
                                    ref={nameRef}
                                    onBlur={() => handleBlur('name')}
                                />
                                {touched.name && errors.name && (
                                    <div className="invalid-feedback small">{errors.name}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Email address</label>
                                <input
                                    type="email"
                                    className={`form-control ${touched.email && errors.email ? 'is-invalid' : ''}`}
                                    placeholder="Enter email"
                                    ref={emailRef}
                                    onBlur={() => handleBlur('email')}
                                />
                                {touched.email && errors.email && (
                                    <div className="invalid-feedback small">{errors.email}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Password</label>
                                <input
                                    type="password"
                                    className={`form-control ${touched.password && errors.password ? 'is-invalid' : ''}`}
                                    placeholder="Password"
                                    ref={passwordRef}
                                    onBlur={() => handleBlur('password')}
                                />
                                {touched.password && errors.password && (
                                    <div className="invalid-feedback small">{errors.password}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <label className="form-label text-muted small mb-1">Profile</label>
                                <input
                                    type="text"
                                    className={`form-control ${touched.profileImage && errors.profileImage ? 'is-invalid' : ''}`}
                                    placeholder="Provide profile image url"
                                    ref={profileImageRef}
                                    onBlur={() => handleBlur('profileImage')}
                                />
                                {touched.profileImage && errors.profileImage && (
                                    <div className="invalid-feedback small">{errors.profileImage}</div>
                                )}
                            </div>

                            <div className="mb-4">
                                <label className="form-label text-muted small mb-1">Role:</label>
                                <select
                                    className={`form-select ${touched.role && errors.role ? 'is-invalid' : ''}`}
                                    ref={roleRef}
                                    onBlur={() => handleBlur('role')}
                                    defaultValue=""
                                >
                                    <option value="">Select your role</option>
                                    <option value="Project Owner">Project Owner</option>
                                    <option value="Assignee">Assignee</option>
                                </select>
                                {touched.role && errors.role && (
                                    <div className="invalid-feedback small">{errors.role}</div>
                                )}
                            </div>

                            <div className="mb-3">
                                <button
                                    type="submit"
                                    className="btn btn-warning btn-login-custom"
                                    disabled={loading}
                                >
                                    {loading ? 'Submitting...' : 'Signup'}
                                </button>
                            </div>

                            <div className="text-center mt-3">
                                <span className="small text-muted">Already have an account? </span>
                                <Link to="/login" className="small text-decoration-none fw-semibold">
                                    Login
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserSignupForm;
