class Issue {
    constructor(id, summary, description, project, assignee, createdBy, createdOn, lastUpdated, sprint, storyPoint, tags, priority, status, type) {
        this.id = id;
        this.summary = summary;
        this.description = description;
        this.project = project;
        this.assignee = assignee;
        this.createdBy = createdBy;
        this.createdOn = createdOn;
        this.lastUpdated = lastUpdated;
        this.sprint = sprint;
        this.storyPoint = storyPoint;
        this.tags = tags;
        this.priority = priority;
        this.status = status;
        this.type = type;
    }
}
export default Issue;
