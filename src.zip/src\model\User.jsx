class User {
    constructor(userId, name, emailId, role, password, profileImage) {
        this.userId = userId;
        this.name = name;
        this.emailId = emailId;
        this.role = role;
        this.password = password;
        this.profileImage = profileImage;
    }
}
export default User;
