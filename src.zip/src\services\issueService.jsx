import axios from "axios";

// Using API Gateway (port 9000) or direct IssueServiceMS fallback (port 8011)
export const ISSUE_API_URL = 'http://localhost:9000/api/v1/issues';

export const getAllIssues = async () => {
    try {
        const response = await axios.get(ISSUE_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching all issues:', error);
        return [];
    }
};

export const getIssueById = async (id) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issue by ID ${id}:`, error);
        throw error;
    }
};

export const createIssue = async (issue) => {
    try {
        const response = await axios.post(ISSUE_API_URL, issue);
        return response.data;
    } catch (error) {
        console.error('Error creating issue:', error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || error.message || 'Failed to create issue';
        throw new Error(errorMsg);
    }
};

export const updateIssue = async (id, issue) => {
    try {
        const response = await axios.put(`${ISSUE_API_URL}/${id}`, issue);
        return response.data;
    } catch (error) {
        console.error(`Error updating issue ${id}:`, error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || error.message || 'Failed to update issue';
        throw new Error(errorMsg);
    }
};

export const getIssuesByAssigneeId = async (assigneeId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/assignee/${assigneeId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issues for assignee ${assigneeId}:`, error);
        return [];
    }
};

export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/project/${projectId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issues for project ${projectId}:`, error);
        return [];
    }
};

export const getIssuesByOwnerId = async (ownerId) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issues for owner ${ownerId}:`, error);
        return [];
    }
};
