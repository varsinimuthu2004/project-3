import axios from "axios";

// Using API Gateway (port 9000) or direct ProjectServiceMS fallback (port 7009)
export const PROJECT_API_URL = 'http://localhost:9000/api/v1/projects';

export const getAllProjects = async () => {
    try {
        const response = await axios.get(PROJECT_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching all projects:', error);
        return [];
    }
};

export const getProjectById = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching project with ID ${projectId}:`, error);
        throw error;
    }
};

export const getProjectsByOwner = async (ownerId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching projects for owner ${ownerId}:`, error);
        return [];
    }
};

export const createProject = async (project) => {
    try {
        const response = await axios.post(PROJECT_API_URL, project);
        return response.data;
    } catch (error) {
        console.error('Error creating project:', error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || error.message || 'Failed to create project';
        throw new Error(errorMsg);
    }
};

export const updateProject = async (projectId, project) => {
    try {
        const response = await axios.put(`${PROJECT_API_URL}/${projectId}`, project);
        return response.data;
    } catch (error) {
        console.error(`Error updating project ${projectId}:`, error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || error.message || 'Failed to update project';
        throw new Error(errorMsg);
    }
};

export const deleteProject = async (projectId) => {
    try {
        const response = await axios.delete(`${PROJECT_API_URL}/${projectId}`);
        return response.data;
    } catch (error) {
        console.error(`Error deleting project ${projectId}:`, error);
        throw error;
    }
};

export const getIssuesByProjectId = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/issues`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issues for project ${projectId}:`, error);
        return [];
    }
};

export const getProjectInsights = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/insights`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching insights for project ${projectId}:`, error);
        return null;
    }
};
