import axios from "axios";

// Using API Gateway (port 9000) or direct UserServiceMS fallback (port 7007)
export const USER_API_URL = 'http://localhost:9000/api/v1/users';

export const registerUser = async (user) => {
    try {
        const response = await axios.post(USER_API_URL, {
            name: user.name,
            emailId: user.emailId,
            password: user.password,
            profileImage: user.profileImage,
            role: user.role
        });
        return response.data;
    } catch (error) {
        console.error('Error Registering the User - ', error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || error.message || 'An error occurred during registration';
        throw new Error(errorMsg);
    }
};

export const login = async (emailId, password, role) => {
    try {
        const response = await axios.post(`${USER_API_URL}/login`, {
            emailId: emailId,
            password: password,
            role: role
        });
        return { success: true, user: response.data };
    } catch (error) {
        console.error('Error Logging in the User - ', error);
        const errorMsg = error.response?.data?.errorMessage || error.response?.data || 'Invalid Credentials';
        return { success: false, user: null, error: errorMsg };
    }
};

export const getAllUsers = async () => {
    try {
        const response = await axios.get(USER_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching users:', error);
        return [];
    }
};

export const getUserById = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching user by ID ${userId}:`, error);
        throw error;
    }
};

export const getIssuesByUserId = async (userId) => {
    try {
        const response = await axios.get(`${USER_API_URL}/${userId}/issues`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching issues for user ${userId}:`, error);
        return [];
    }
};
