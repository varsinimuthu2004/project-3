package com.issue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueServiceMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssueServiceMsApplication.class, args);
	}

}
