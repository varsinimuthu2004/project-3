package com.issue.model;

import java.time.LocalDate;

import com.issue.utility.Priority;
import com.issue.utility.Status;
import com.issue.utility.Type;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class IssueDTO {
	
	private Integer id;

	@NotNull(message = "Summary cannot be null")
	@Size(min = 5, max = 255, message = "Summary must be between 5 and 255 characters")
	private String summary;
	
	@Size(max = 255, message = "Description cannot exceed 255 characters")
	private String description;
	
	@NotNull(message = "Project ID cannot be null")
	private Integer project;
	
	private Integer assignee;
	
	@NotNull(message = "Creator User ID (createdBy) cannot be null")
	private Integer createdBy;
	
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	
	@Min(value = 0, message = "Story points cannot be negative")
	@Max(value = 21, message = "Story points cannot exceed 21")
	private Integer storyPoint;
	
	private String tags;
	
	@NotNull(message = "Priority cannot be null")
	//@Enumerated(EnumType.STRING) 
	private Priority priority;
	
	@NotNull(message = "Status cannot be null")
	//@Enumerated(EnumType.STRING) 
	private Status status;
	
	@NotNull(message = "Issue type cannot be null")
	//@Enumerated(EnumType.STRING) 
	private Type type;
}
