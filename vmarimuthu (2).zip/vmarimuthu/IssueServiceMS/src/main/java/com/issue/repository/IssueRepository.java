package com.issue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import com.issue.entity.Issue;

@Repository
public interface IssueRepository extends JpaRepository<Issue,Integer> {
	List<Issue> findByAssignee(Integer assignee);
	List<Issue> findByProject(Integer project);
	List<Issue> findByCreatedBy(Integer createdBy);


}
