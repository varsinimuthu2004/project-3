package com.issue.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.issue.entity.Issue;
import com.issue.exception.IssueException;
import com.issue.model.IssueDTO;
import com.issue.repository.IssueRepository;

@Service
public class IssueServiceImpl implements IssueService {
	@Autowired
	private IssueRepository issueRepository;
	
	@Override
	public IssueDTO getIssueById(Integer id) throws IssueException {
		Optional<Issue> optional = issueRepository.findById(id);
		IssueDTO dto = new IssueDTO();
		try {
			Issue issue = optional.orElseThrow(() -> new IssueException("Issue not found with ID: " + id));
			dto.setId(issue.getId());
			dto.setSummary(issue.getSummary());
			dto.setDescription(issue.getDescription());
			dto.setProject(issue.getProject());
			dto.setAssignee(issue.getAssignee());
			dto.setCreatedBy(issue.getCreatedBy());
			dto.setCreatedOn(issue.getCreatedOn());
			dto.setLastUpdated(issue.getLastUpdated());
			dto.setSprint(issue.getSprint());
			dto.setStoryPoint(issue.getStoryPoint());
			dto.setTags(issue.getTags());
			dto.setPriority(issue.getPriority());
			dto.setStatus(issue.getStatus());
			dto.setType(issue.getType());
		} catch(Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
		return dto;
	}

	@Override
	public String createIssue(IssueDTO issueDTO) throws IssueException {
		Issue issue = new Issue();
		issue.setSummary(issueDTO.getSummary());
		issue.setDescription(issueDTO.getDescription());
		issue.setProject(issueDTO.getProject());
		issue.setAssignee(issueDTO.getAssignee());
		issue.setCreatedBy(issueDTO.getCreatedBy());
		
		issue.setCreatedOn(LocalDate.now());
		issue.setLastUpdated(LocalDate.now());
		
		issue.setSprint(issueDTO.getSprint());
		issue.setStoryPoint(issueDTO.getStoryPoint());
		issue.setTags(issueDTO.getTags());
		issue.setPriority(issueDTO.getPriority());
		issue.setStatus(issueDTO.getStatus());
		issue.setType(issueDTO.getType());
		try {
			issueRepository.save(issue);
		} catch(Exception exception) {
			throw exception;
		}
		return "Issue created successfully with Issue ID: " + issue.getId();
	}

	@Override
	public List<IssueDTO> getAllIssues() throws IssueException {
		List<Issue> issuesList = issueRepository.findAll();
		List<IssueDTO> dtoList = new ArrayList<>();
		try {
			for (Issue issue : issuesList) {
				IssueDTO dto = new IssueDTO();
				dto.setId(issue.getId());
				dto.setSummary(issue.getSummary());
				dto.setDescription(issue.getDescription());
				dto.setProject(issue.getProject());
				dto.setAssignee(issue.getAssignee());
				dto.setCreatedBy(issue.getCreatedBy());
				dto.setCreatedOn(issue.getCreatedOn());
				dto.setLastUpdated(issue.getLastUpdated());
				dto.setSprint(issue.getSprint());
				dto.setStoryPoint(issue.getStoryPoint());
				dto.setTags(issue.getTags());
				dto.setPriority(issue.getPriority());
				dto.setStatus(issue.getStatus());
				dto.setType(issue.getType());
				dtoList.add(dto);
			}
		} catch(Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
		return dtoList;
	}

	@Override
	public String updateIssue(Integer id, IssueDTO issueDTO) throws IssueException {
		Optional<Issue> optional = issueRepository.findById(id);
		try {
			Issue issue = optional.orElseThrow(() -> new IssueException("Issue not found with ID: " + id));
			issue.setSummary(issueDTO.getSummary());
			issue.setDescription(issueDTO.getDescription());
			issue.setProject(issueDTO.getProject());
			issue.setAssignee(issueDTO.getAssignee());
			issue.setCreatedBy(issueDTO.getCreatedBy());
			
			issue.setLastUpdated(LocalDate.now());
			
			issue.setSprint(issueDTO.getSprint());
			issue.setStoryPoint(issueDTO.getStoryPoint());
			issue.setTags(issueDTO.getTags());
			issue.setPriority(issueDTO.getPriority());
			issue.setStatus(issueDTO.getStatus());
			issue.setType(issueDTO.getType());
			
			issueRepository.save(issue);
		} catch(Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
		return "Issue details updated successfully for ID: " + id;
	}
	
	@Override
	public List<IssueDTO> getIssuesByAssigneeId(Integer assigneeId) throws IssueException {
		List<Issue> issuesList = issueRepository.findByAssignee(assigneeId);
		List<IssueDTO> dtoList = new ArrayList<>();
		try {
			for (Issue issue : issuesList) {
				IssueDTO dto = new IssueDTO();
				dto.setId(issue.getId());
				dto.setSummary(issue.getSummary());
				dto.setDescription(issue.getDescription());
				dto.setProject(issue.getProject());
				dto.setAssignee(issue.getAssignee());
				dto.setCreatedBy(issue.getCreatedBy());
				dto.setCreatedOn(issue.getCreatedOn());
				dto.setLastUpdated(issue.getLastUpdated());
				dto.setSprint(issue.getSprint());
				dto.setStoryPoint(issue.getStoryPoint());
				dto.setTags(issue.getTags());
				dto.setPriority(issue.getPriority());
				dto.setStatus(issue.getStatus());
				dto.setType(issue.getType());
				dtoList.add(dto);
			}
		} catch(Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
		return dtoList;
	}
	
	@Override
	public List<IssueDTO> getIssuesByProjectId(Integer projectId) throws IssueException {
	    List<Issue> issuesList = issueRepository.findByProject(projectId);
	    List<IssueDTO> dtoList = new ArrayList<>();
	    try {
	        for (Issue issue : issuesList) {
	            IssueDTO dto = new IssueDTO();
	            dto.setId(issue.getId());
	            dto.setSummary(issue.getSummary());
	            dto.setDescription(issue.getDescription());
	            dto.setProject(issue.getProject());
	            dto.setAssignee(issue.getAssignee());
	            dto.setCreatedBy(issue.getCreatedBy());
	            dto.setCreatedOn(issue.getCreatedOn());
	            dto.setLastUpdated(issue.getLastUpdated());
	            dto.setSprint(issue.getSprint());
	            dto.setStoryPoint(issue.getStoryPoint());
	            dto.setTags(issue.getTags());
	            dto.setPriority(issue.getPriority());
	            dto.setStatus(issue.getStatus());
	            dto.setType(issue.getType());
	            dtoList.add(dto);
	        }
	    } catch(Exception exception) {
	        exception.printStackTrace();
	        throw exception;
	    }
	    return dtoList;
	}

	@Override
	public List<IssueDTO> getIssuesByOwnerId(Integer ownerId) throws IssueException {
	    List<Issue> issuesList = issueRepository.findByCreatedBy(ownerId);
	    List<IssueDTO> dtoList = new ArrayList<>();
	    try {
	        for (Issue issue : issuesList) {
	            IssueDTO dto = new IssueDTO();
	            dto.setId(issue.getId());
	            dto.setSummary(issue.getSummary());
	            dto.setDescription(issue.getDescription());
	            dto.setProject(issue.getProject());
	            dto.setAssignee(issue.getAssignee());
	            dto.setCreatedBy(issue.getCreatedBy());
	            dto.setCreatedOn(issue.getCreatedOn());
	            dto.setLastUpdated(issue.getLastUpdated());
	            dto.setSprint(issue.getSprint());
	            dto.setStoryPoint(issue.getStoryPoint());
	            dto.setTags(issue.getTags());
	            dto.setPriority(issue.getPriority());
	            dto.setStatus(issue.getStatus());
	            dto.setType(issue.getType());
	            dtoList.add(dto);
	        }
	    } catch(Exception exception) {
	        exception.printStackTrace();
	        throw exception;
	    }
	    return dtoList;
	}
}


/*
 * package com.issue.service;
 * 
 * import java.time.LocalDate; import java.util.ArrayList; import
 * java.util.List; import java.util.Optional;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service;
 * 
 * import com.issue.entity.Issue; import com.issue.exception.IssueException;
 * import com.issue.model.IssueDTO; import com.issue.repository.IssueRepository;
 * 
 * @Service public class IssueServiceImpl implements IssueService {
 * 
 * @Autowired private IssueRepository issueRepository;
 * 
 * @Override public IssueDTO getIssueById(Integer id) throws IssueException {
 * Optional<Issue> optional = issueRepository.findById(id); IssueDTO dto = new
 * IssueDTO(); try { Issue issue = optional.orElseThrow(() -> new
 * IssueException("Issue not found with ID: " + id)); dto.setId(issue.getId());
 * dto.setSummary(issue.getSummary());
 * dto.setDescription(issue.getDescription());
 * dto.setProject(issue.getProject()); dto.setAssignee(issue.getAssignee());
 * dto.setCreatedBy(issue.getCreatedBy());
 * dto.setCreatedOn(issue.getCreatedOn());
 * dto.setLastUpdated(issue.getLastUpdated()); dto.setSprint(issue.getSprint());
 * dto.setStoryPoint(issue.getStoryPoint()); dto.setTags(issue.getTags());
 * dto.setPriority(issue.getPriority()); dto.setStatus(issue.getStatus());
 * dto.setType(issue.getType()); } catch(Exception exception) {
 * exception.printStackTrace(); throw exception; } return dto; }
 * 
 * @Override public String createIssue(IssueDTO issueDTO) throws IssueException
 * { Issue issue = new Issue(); issue.setSummary(issueDTO.getSummary());
 * issue.setDescription(issueDTO.getDescription());
 * issue.setProject(issueDTO.getProject());
 * issue.setAssignee(issueDTO.getAssignee());
 * issue.setCreatedBy(issueDTO.getCreatedBy());
 * 
 * // Map creation metrics seamlessly issue.setCreatedOn(LocalDate.now());
 * issue.setLastUpdated(LocalDate.now());
 * 
 * issue.setSprint(issueDTO.getSprint());
 * issue.setStoryPoint(issueDTO.getStoryPoint());
 * issue.setTags(issueDTO.getTags()); issue.setPriority(issueDTO.getPriority());
 * issue.setStatus(issueDTO.getStatus()); issue.setType(issueDTO.getType()); try
 * { issueRepository.save(issue); } catch(Exception exception) { throw
 * exception; } return "Issue created successfully with Issue ID: " +
 * issue.getId(); }
 * 
 * @Override public List<IssueDTO> getAllIssues() throws IssueException {
 * List<Issue> issuesList = issueRepository.findAll(); List<IssueDTO> dtoList =
 * new ArrayList<>(); try { if(issuesList.isEmpty()) { throw new
 * IssueException("No issues found in the database."); } for (Issue issue :
 * issuesList) { IssueDTO dto = new IssueDTO(); dto.setId(issue.getId());
 * dto.setSummary(issue.getSummary());
 * dto.setDescription(issue.getDescription());
 * dto.setProject(issue.getProject()); dto.setAssignee(issue.getAssignee());
 * dto.setCreatedBy(issue.getCreatedBy());
 * dto.setCreatedOn(issue.getCreatedOn());
 * dto.setLastUpdated(issue.getLastUpdated()); dto.setSprint(issue.getSprint());
 * dto.setStoryPoint(issue.getStoryPoint()); dto.setTags(issue.getTags());
 * dto.setPriority(issue.getPriority()); dto.setStatus(issue.getStatus());
 * dto.setType(issue.getType()); dtoList.add(dto); } } catch(Exception
 * exception) { exception.printStackTrace(); throw exception; } return dtoList;
 * }
 * 
 * @Override public String updateIssue(Integer id, IssueDTO issueDTO) throws
 * IssueException { Optional<Issue> optional = issueRepository.findById(id); try
 * { Issue issue = optional.orElseThrow(() -> new
 * IssueException("Issue not found with ID: " + id));
 * issue.setSummary(issueDTO.getSummary());
 * issue.setDescription(issueDTO.getDescription());
 * issue.setProject(issueDTO.getProject());
 * issue.setAssignee(issueDTO.getAssignee());
 * issue.setCreatedBy(issueDTO.getCreatedBy());
 * 
 * // Maintain last modification baseline metrics automatically
 * issue.setLastUpdated(LocalDate.now());
 * 
 * issue.setSprint(issueDTO.getSprint());
 * issue.setStoryPoint(issueDTO.getStoryPoint());
 * issue.setTags(issueDTO.getTags()); issue.setPriority(issueDTO.getPriority());
 * issue.setStatus(issueDTO.getStatus()); issue.setType(issueDTO.getType());
 * 
 * issueRepository.save(issue); } catch(Exception exception) {
 * exception.printStackTrace(); throw exception; } return
 * "Issue details updated successfully for ID: " + id; }
 * 
 * @Override public List<IssueDTO> getIssuesByAssigneeId(Integer assigneeId)
 * throws IssueException { List<Issue> issuesList =
 * issueRepository.findByAssignee(assigneeId); List<IssueDTO> dtoList = new
 * ArrayList<>(); try { if(issuesList.isEmpty()) { throw new
 * IssueException("No issues discovered for Assignee ID: " + assigneeId); } for
 * (Issue issue : issuesList) { IssueDTO dto = new IssueDTO();
 * dto.setId(issue.getId()); dto.setSummary(issue.getSummary());
 * dto.setDescription(issue.getDescription());
 * dto.setProject(issue.getProject()); dto.setAssignee(issue.getAssignee());
 * dto.setCreatedBy(issue.getCreatedBy());
 * dto.setCreatedOn(issue.getCreatedOn());
 * dto.setLastUpdated(issue.getLastUpdated()); dto.setSprint(issue.getSprint());
 * dto.setStoryPoint(issue.getStoryPoint()); dto.setTags(issue.getTags());
 * dto.setPriority(issue.getPriority()); dto.setStatus(issue.getStatus());
 * dto.setType(issue.getType()); dtoList.add(dto); } } catch(Exception
 * exception) { exception.printStackTrace(); throw exception; } return dtoList;
 * }
 * 
 * @Override public List<IssueDTO> getIssuesByProjectId(Integer projectId)
 * throws IssueException { List<Issue> issuesList =
 * issueRepository.findByProject(projectId); List<IssueDTO> dtoList = new
 * ArrayList<>(); try { if(issuesList.isEmpty()) { throw new
 * IssueException("No issues discovered for Project ID: " + projectId); } for
 * (Issue issue : issuesList) { IssueDTO dto = new IssueDTO();
 * dto.setId(issue.getId()); dto.setSummary(issue.getSummary());
 * dto.setDescription(issue.getDescription());
 * dto.setProject(issue.getProject()); dto.setAssignee(issue.getAssignee());
 * dto.setCreatedBy(issue.getCreatedBy());
 * dto.setCreatedOn(issue.getCreatedOn());
 * dto.setLastUpdated(issue.getLastUpdated()); dto.setSprint(issue.getSprint());
 * dto.setStoryPoint(issue.getStoryPoint()); dto.setTags(issue.getTags());
 * dto.setPriority(issue.getPriority()); dto.setStatus(issue.getStatus());
 * dto.setType(issue.getType()); dtoList.add(dto); } } catch(Exception
 * exception) { exception.printStackTrace(); throw exception; } return dtoList;
 * }
 * 
 * @Override public List<IssueDTO> getIssuesByOwnerId(Integer ownerId) throws
 * IssueException { List<Issue> issuesList =
 * issueRepository.findByCreatedBy(ownerId); List<IssueDTO> dtoList = new
 * ArrayList<>(); try { if(issuesList.isEmpty()) { throw new
 * IssueException("No issues discovered for Owner ID: " + ownerId); } for (Issue
 * issue : issuesList) { IssueDTO dto = new IssueDTO();
 * dto.setId(issue.getId()); dto.setSummary(issue.getSummary());
 * dto.setDescription(issue.getDescription());
 * dto.setProject(issue.getProject()); dto.setAssignee(issue.getAssignee());
 * dto.setCreatedBy(issue.getCreatedBy());
 * dto.setCreatedOn(issue.getCreatedOn());
 * dto.setLastUpdated(issue.getLastUpdated()); dto.setSprint(issue.getSprint());
 * dto.setStoryPoint(issue.getStoryPoint()); dto.setTags(issue.getTags());
 * dto.setPriority(issue.getPriority()); dto.setStatus(issue.getStatus());
 * dto.setType(issue.getType()); dtoList.add(dto); } } catch(Exception
 * exception) { exception.printStackTrace(); throw exception; } return dtoList;
 * }
 * 
 * }
 */