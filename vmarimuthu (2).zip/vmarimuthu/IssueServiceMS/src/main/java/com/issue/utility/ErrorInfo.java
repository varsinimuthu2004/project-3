package com.issue.utility;

public class ErrorInfo {

}
