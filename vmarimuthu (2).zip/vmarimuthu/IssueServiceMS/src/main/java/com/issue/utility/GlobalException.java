package com.issue.utility;

public class GlobalException {

}
