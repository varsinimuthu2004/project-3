package com.issue.utility;

public enum Priority {
	HIGH, MEDIUM, LOW
}
