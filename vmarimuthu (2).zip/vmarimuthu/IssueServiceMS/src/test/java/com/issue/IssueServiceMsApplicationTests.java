package com.issue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
