package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;
import com.project.service.ProjectService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@GetMapping("/{projectId}")
	public ResponseEntity<ProjectDTO> getProjectById(@PathVariable Integer projectId) throws ProjectException {
		ProjectDTO projectDTO = projectService.getProjectById(projectId);
		return new ResponseEntity<>(projectDTO, HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<String> createProject(@Valid @RequestBody ProjectDTO projectDTO) throws ProjectException {
		String message = projectService.createProject(projectDTO);
		return new ResponseEntity<>(message, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<ProjectDTO>> getAllProjects() throws ProjectException {
		List<ProjectDTO> projects = projectService.getAllProjects();
		return new ResponseEntity<>(projects, HttpStatus.OK);
	}
	
	@GetMapping("/owner/{ownerId}")
	public ResponseEntity<List<ProjectDTO>> getProjectsByOwner(@PathVariable Integer ownerId) throws ProjectException {
		List<ProjectDTO> projects = projectService.getProjectsByOwner(ownerId);
		return new ResponseEntity<>(projects, HttpStatus.OK);
	}
	
	@PutMapping("/{projectId}")
	public ResponseEntity<String> updateProject(@PathVariable Integer projectId, @Valid @RequestBody ProjectDTO projectDTO) throws ProjectException {
		String message = projectService.updateProject(projectId, projectDTO);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	@DeleteMapping("/{projectId}")
	public ResponseEntity<String> deleteProject(@PathVariable Integer projectId) throws ProjectException {
		String message = projectService.deleteProject(projectId);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	@GetMapping("/{projectId}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByProjectId(@PathVariable Integer projectId) throws Exception {
	    List<IssueDTO> issues = projectService.getIssuesByProjectId(projectId);
	    return new ResponseEntity<>(issues, HttpStatus.OK);
	}

	@GetMapping("/projectName/{projectName}/issues")
	public ResponseEntity<List<IssueDTO>> getIssuesByProjectName(@PathVariable String projectName) throws Exception {
	    List<IssueDTO> issues = projectService.getIssuesByProjectName(projectName);
	    return new ResponseEntity<>(issues, HttpStatus.OK);
	}

}
