package com.project.entity;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;

@Entity
@Data
@Table(name = "project") 
public class Project {
	
	@Id
	@TableGenerator(name = "project_gen", initialValue = 3010, allocationSize = 1,
			table = "project_seq", pkColumnName = "seq_name", valueColumnName = "seq_value")
	@GeneratedValue(generator = "project_gen")
	private Integer id;
	
	private String projectName;
	private Integer projectOwner;
	private LocalDate startDate;
	private LocalDate endDate;
}
