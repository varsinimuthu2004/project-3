package com.project.model;

import java.time.LocalDate;


import com.project.utility.Priority;
import com.project.utility.Status;
import com.project.utility.Type;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class IssueDTO {
	private Integer id;
	private String summary;
	private String description;
	private Integer project;
	private Integer assignee;
	private Integer createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
	
	@Enumerated(EnumType.STRING)
	private Priority priority;
	
	@Enumerated(EnumType.STRING)
	private Status status;
	
	@Enumerated(EnumType.STRING)
	private Type type;
}
