package com.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.project.entity.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {
	
	List<Project> findByProjectOwner(Integer projectOwner);

	Optional<Project> findByProjectName(String projectName);
}