package com.project.service;

import java.util.List;

import com.project.exception.ProjectException;
import com.project.model.IssueDTO;
import com.project.model.ProjectDTO;

public interface ProjectService {

	ProjectDTO getProjectById(Integer projectId) throws ProjectException;

	String createProject(ProjectDTO projectDTO) throws ProjectException;

	List<ProjectDTO> getAllProjects() throws ProjectException;

	List<ProjectDTO> getProjectsByOwner(Integer ownerId) throws ProjectException;

	String updateProject(Integer projectId, ProjectDTO projectDTO) throws ProjectException;

	String deleteProject(Integer projectId) throws ProjectException;
	
	List<IssueDTO> getIssuesByProjectId(Integer projectId) throws Exception;

	List<IssueDTO> getIssuesByProjectName(String projectName) throws Exception;

}
