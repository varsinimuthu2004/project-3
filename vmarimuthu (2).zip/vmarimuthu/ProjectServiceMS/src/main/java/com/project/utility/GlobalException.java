package com.project.utility;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.project.exception.ProjectException;

@RestControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> handleValidationException(MethodArgumentNotValidException exception){
		
		ErrorInfo errorInfo = new ErrorInfo();
		String message = exception.getBindingResult()
		.getAllErrors()
		.stream()
		.map(error -> error.getDefaultMessage())
		.collect(Collectors.joining(", "));
		
		errorInfo.setErrorMessage(message);
		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorInfo.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value = ProjectException.class)
	public ResponseEntity<ErrorInfo> handleProjectException(ProjectException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errorInfo.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
