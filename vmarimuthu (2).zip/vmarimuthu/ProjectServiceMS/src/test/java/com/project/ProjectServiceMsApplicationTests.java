package com.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectServiceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
