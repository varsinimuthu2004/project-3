package com.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.user")
public class UserServiceMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiceMsApplication.class, args);
	}

}
