package com.user.entity;

import com.user.utility.Role;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;

@Entity
@Data
@Table(name = "users") 
public class User {

	@Id
	@TableGenerator(name = "user_gen", initialValue = 1000, allocationSize = 1, 
	table = "user_seq", pkColumnName = "gen_name", valueColumnName = "gen_value")
	@GeneratedValue(generator = "user_gen")
	private Long userId;
	
	private String name;
	private String emailId;
	private Role role;
	private String password;
	private String profileImage;

}
