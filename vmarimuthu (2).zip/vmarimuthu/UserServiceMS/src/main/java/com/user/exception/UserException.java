package com.user.exception;

@SuppressWarnings("serial")
public class UserException extends Exception {
	//private static final long serialVersionUID = 1L;

	public UserException(String message) {
		super(message);
	}
}
