package com.user.model;

import java.time.LocalDate;

import com.user.utility.Priority;
import com.user.utility.Type;

import ch.qos.logback.core.status.Status;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class IssueDTO {
	
	private Integer id;
	private String summary;
	private String description;
	private Integer project;
	private Integer assignee;
	private Integer createdBy;
	private LocalDate createdOn;
	private LocalDate lastUpdated;
	private String sprint;
	private Integer storyPoint;
	private String tags;
	
	@Enumerated(EnumType.STRING)
	private Priority priority;
	
	@Enumerated(EnumType.STRING)
	private Status status;
	
	@Enumerated(EnumType.STRING)
	private Type type;
}
