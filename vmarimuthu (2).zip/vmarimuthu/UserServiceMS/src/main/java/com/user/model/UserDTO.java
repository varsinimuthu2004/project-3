package com.user.model;

import com.user.utility.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserDTO {
	
	private Long userId;
	
	@NotNull(message = "Name cannot be null")
	@Size(min = 2, max = 255, message = "Name must be between 2 and 255 characters")
	private String name;

	@NotNull(message = "Email ID cannot be null")
	@Email(message = "Please provide a valid email address")
	private String emailId;
	
	@NotNull(message = "Role cannot be null")
	@Enumerated(EnumType.STRING)
	private Role role;
	
	@NotNull(message = "Password cannot be null")
	@Size(min = 6, message = "Password must be at least 6 characters long")
	private String password;
	
	private String profileImage;
}
