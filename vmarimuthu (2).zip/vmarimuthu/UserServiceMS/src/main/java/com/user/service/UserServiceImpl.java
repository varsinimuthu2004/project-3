package com.user.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.client.IssueFeign;
import com.user.entity.User;
import com.user.exception.UserException;
import com.user.model.IssueDTO;
import com.user.model.UserDTO;
import com.user.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	
	 @Autowired private ModelMapper mapper;

	@Autowired
	private IssueFeign issueFeign;

	/*
	 * @Override public String registerUser(UserDTO userDTO) { try { User user = new
	 * User(); mapper.map(userDTO, user); userRepository.save(user); } catch
	 * (Exception exception) { throw exception; } return
	 * "User Registered successfully"; }
	 */

	@Override
	public String registerUser(UserDTO userDTO) throws UserException {
	    User user = new User();
	    user.setName(userDTO.getName());
	    user.setEmailId(userDTO.getEmailId());
	    user.setRole(userDTO.getRole());
	    user.setPassword(userDTO.getPassword());
	    
	    userRepository.save(user);
	    
	    return "User registered successfully with User ID: " + user.getUserId();
	}


	@Override
	public UserDTO loginUser(String name,String emailId, String password, String Role ) throws UserException {
		User user = userRepository.findByEmailId(emailId);
		try {
			if (user == null) {
				throw new UserException("User not found");
			}
			if (!user.getPassword().equals(password)) {
				throw new UserException("Invalid password");
			}
			UserDTO userDTO = mapper.map(user, UserDTO.class);
			return userDTO;
		} catch (Exception exception) {
			throw exception;
		}
	}

	@Override
	public UserDTO getUserById(Integer userId) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		UserDTO userDTO = new UserDTO();

		try {
			User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));
			userDTO.setUserId(user.getUserId());
			userDTO.setName(user.getName());
			userDTO.setEmailId(user.getEmailId());
			userDTO.setRole(user.getRole());
			userDTO.setPassword(user.getPassword());
			userDTO.setProfileImage(user.getProfileImage());
		} catch (UserException e) {
			e.printStackTrace();
			throw e;
		}
		return userDTO;
	}

	@Override
	public List<UserDTO> getAllUsers() throws UserException {
		List<User> usersList = userRepository.findAll();
		List<UserDTO> userdtoList = new ArrayList<>();

		try {
			if (usersList.isEmpty()) {
				throw new UserException("No users found in the database.");
			}
			for (User user : usersList) {
				UserDTO dto = new UserDTO();
				dto.setUserId(user.getUserId());
				dto.setName(user.getName());
				dto.setEmailId(user.getEmailId());
				dto.setRole(user.getRole());
				dto.setPassword(user.getPassword());
				dto.setProfileImage(user.getProfileImage());
				userdtoList.add(dto);
			}
		} catch (UserException e) {
			e.printStackTrace();
			throw e;
		}
		return userdtoList;
	}

	@Override
	public String updateUser(Integer userId, UserDTO userDTO) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		user.setEmailId(userDTO.getEmailId());
		user.setName(userDTO.getName());
		user.setRole(userDTO.getRole());
		user.setPassword(userDTO.getPassword());
		user.setProfileImage(userDTO.getProfileImage());

		userRepository.save(user);
		return "User details updated successfully for User ID: " + userId;
	}

	@Override
	public String deleteUser(Integer userId) throws UserException {
		Optional<User> optional = userRepository.findById(userId);
		User user = optional.orElseThrow(() -> new UserException("User not found with ID: " + userId));

		userRepository.delete(user);
		return "User deleted successfully with User ID: " + userId;
	}
	
	
	@Override
	public List<IssueDTO> getIssuesByUserId(Long userId) throws Exception {
	    List<IssueDTO> issues = null;
	    try {
	        issues = issueFeign.getIssuesByAssigneeId(userId); //Internal call to issue service using feign client
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("Issue service returned no issues found for the user.");
	        }
	    } catch (Exception exception) { 
	        throw new Exception("Issue service is down or an error occurred: " + exception.getMessage()); 
	    }
	    
	    return issues;
	}

	@Override
	public List<IssueDTO> getIssuesByUsername(String username) throws Exception {

	    User user = userRepository.findByName(username)
	            .orElseThrow(() -> new UserException("User profile not found with name: " + username));
	            
	    List<IssueDTO> issues = null;
	    try {
	        issues = issueFeign.getIssuesByAssigneeId(user.getUserId());
	        if (issues == null || issues.isEmpty()) {
	            throw new Exception("No active issues found assigned to user name: " + username);
	        }
	    } catch (Exception exception) {
	        throw new Exception("Downstream issue service communication failure: " + exception.getMessage());
	    }
	    return issues;
	}

}
